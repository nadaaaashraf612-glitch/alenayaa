<?php
if (!defined('ABSPATH')) { exit; }
al_set_header_variant('internal');
status_header(404);
get_header();
?>
<main class="legal-main">
<section class="legal-hero"><div class="shell legal-hero-inner"><h1><?php al_e('single.404.title'); ?></h1><p><?php al_e('single.404.text'); ?></p></div></section>
<div class="shell al-results"><a class="al-result" href="<?php echo esc_url(home_url('/')); ?>"><h3><?php al_e('single.404.back'); ?></h3></a></div>
</main>
<?php get_footer(); ?>
