<?php if (!defined('ABSPATH')) { exit; } ?>
<footer class="footer" id="site-footer" data-od-id="site-footer">
<div class="shell footer-inner">
    <div class="footer-main">
        <div class="footer-brand">
            <a class="brand brand-en" href="<?php echo esc_url(home_url('/')); ?>" aria-label="AL-ENAYA — Home"><span class="brand-logo-image brand-logo-icon" role="img" aria-label="AL-ENAYA icon"></span><span class="brand-wordmark">AL-ENAYA</span></a>
            <a class="brand brand-ar" href="<?php echo esc_url(home_url('/')); ?>" aria-label="العناية — الرئيسية"><span class="brand-logo-image brand-logo-full" role="img" aria-label="شعار العناية"></span></a>
            <p><?php al_e('global.footer.about'); ?></p>
        </div>
        <nav aria-label="Site links"><h3><?php al_e('global.footer.company'); ?></h3>
            <div class="footer-links">
                <a href="<?php echo esc_url(home_url('/')); ?>"><?php al_e('global.nav.home'); ?></a>
                <a href="<?php echo esc_url(al_url('about')); ?>"><?php al_e('global.nav.about'); ?></a>
                <a href="<?php echo esc_url(al_url('services')); ?>"><?php al_e('global.nav.services'); ?></a>
                <a href="<?php echo esc_url(al_url('projects')); ?>"><?php al_e('global.nav.projects'); ?></a>
                <a href="<?php echo esc_url(al_url('faq')); ?>"><?php al_e('global.footer.faq'); ?></a>
                <a href="<?php echo esc_url(al_url('privacy')); ?>"><?php al_e('global.footer.privacy'); ?></a>
            </div></nav>
        <div><h3><?php al_e('global.footer.services'); ?></h3>
            <div class="footer-links">
                <a href="<?php echo esc_url(al_service_url('air-duct-cleaning')); ?>"><?php al_e('global.footer.svc1'); ?></a>
                <a href="<?php echo esc_url(al_service_url('hood-cleaning')); ?>"><?php al_e('global.footer.svc2'); ?></a>
                <a href="<?php echo esc_url(al_service_url('tank-cleaning')); ?>"><?php al_e('global.footer.svc3'); ?></a>
                <a href="<?php echo esc_url(al_url('services')); ?>"><?php al_e('global.footer.svc4'); ?></a>
            </div></div>
        <div><h3><?php al_e('global.footer.contact'); ?></h3>
            <div class="contact-list">
                <a class="contact-item" href="<?php echo esc_url(al_url('contact')); ?>"><svg viewBox="0 0 24 24"><path d="M4 5h16v14H4zM4 7l8 6 8-6"/></svg><span><?php al_e('global.footer.request'); ?></span></a>
                <span class="contact-item"><svg viewBox="0 0 24 24"><path d="M12 21s7-5 7-12a7 7 0 1 0-14 0c0 7 7 12 7 12Z"/><circle cx="12" cy="9" r="2"/></svg><span><?php al_e('global.footer.address'); ?></span></span>
            </div>
            <h3 style="margin-top:24px"><?php al_e('global.footer.follow'); ?></h3>
            <div class="socials">
                <a class="social-link" href="<?php echo esc_url(al_opt('social_linkedin')); ?>" aria-label="LinkedIn" target="_blank" rel="noopener"><svg viewBox="0 0 24 24"><path d="M7 9v8M7 6v.01M11 17v-4a4 4 0 0 1 8 0v4M11 9v8"/></svg></a>
                <a class="social-link" href="<?php echo esc_url(al_opt('social_instagram')); ?>" aria-label="Instagram" target="_blank" rel="noopener"><svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="4"/><circle cx="12" cy="12" r="3.5"/><path d="M17.5 6.5h.01"/></svg></a>
                <a class="social-link" href="<?php echo esc_url(al_opt('social_x')); ?>" aria-label="X" target="_blank" rel="noopener"><svg viewBox="0 0 24 24"><path d="m5 5 14 14M19 5 5 19"/></svg></a>
            </div>
        </div>
    </div>
    <div class="footer-bottom"><span><?php al_e('global.footer.copy'); ?></span><span class="footer-legal"><a href="<?php echo esc_url(al_url('faq')); ?>"><?php al_e('global.footer.faq'); ?></a><a href="<?php echo esc_url(al_url('privacy')); ?>"><?php al_e('global.footer.privacy'); ?></a></span></div>
</div>
</footer>
<a class="whatsapp-fab" href="<?php echo esc_url(al_whatsapp_url()); ?>" target="_blank" rel="noopener" aria-label="WhatsApp" data-od-id="whatsapp-sticky">
<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12.04 2A9.84 9.84 0 0 0 3.58 16.86L2 22l5.27-1.54A9.86 9.86 0 1 0 12.04 2Zm0 17.94a8.04 8.04 0 0 1-4.1-1.12l-.29-.17-3.13.92.94-3.05-.19-.31a8.08 8.08 0 1 1 6.77 3.73Zm4.43-6.04c-.24-.12-1.44-.71-1.66-.79-.22-.08-.38-.12-.55.12-.16.24-.63.79-.77.95-.14.16-.28.18-.53.06-.24-.12-1.03-.38-1.96-1.21-.72-.65-1.21-1.44-1.35-1.68-.14-.24-.02-.37.11-.49.11-.11.24-.28.36-.42.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.55-1.32-.75-1.81-.2-.48-.4-.41-.55-.42h-.46c-.16 0-.42.06-.65.3-.22.24-.85.83-.85 2.03 0 1.2.87 2.35.99 2.51.12.16 1.72 2.62 4.16 3.68.58.25 1.04.4 1.39.51.58.18 1.11.16 1.53.1.47-.07 1.44-.59 1.64-1.16.2-.57.2-1.06.14-1.16-.06-.1-.22-.16-.47-.28Z"/></svg></a>
<a class="global-certifications-tab" href="<?php echo esc_url(al_url('certifications')); ?>" aria-label="Certifications"><span><?php al_e('global.cert.tab'); ?></span></a>
<?php wp_footer(); ?>
</body>
</html>
