jQuery(function ($) {
  $(document).on('click', '.al-pick', function (e) {
    e.preventDefault();
    var $row = $(this).closest('.al-img, .al-rep-img');
    var frame = wp.media({ title: 'اختر صورة', multiple: false, library: { type: 'image' } });
    frame.on('select', function () {
      var a = frame.state().get('selection').first().toJSON();
      $row.find('.al-img-url').val(a.url); $row.find('img').attr('src', a.url);
    });
    frame.open();
  });
  $(document).on('click', '.al-unpick', function () { $(this).closest('.al-img').find('.al-img-url').val(''); });
  $('.al-repeater').each(function () {
    var $r = $(this), $list = $r.find('.al-rep-list'), tpl = $r.find('.al-rep-tpl').html();
    function reindex() { $list.children().each(function (i) { $(this).find('[name]').each(function () { this.name = this.name.replace(/\[(\d+|__i__)\]/, '[' + i + ']'); }); }); }
    $list.sortable({ handle: '.al-handle', update: reindex });
    $r.on('click', '.al-add', function () { var n = $list.children().length; $list.append(tpl.replace(/__i__/g, n)); reindex(); });
    $r.on('click', '.al-del', function () { $(this).closest('li').remove(); reindex(); });
    $r.on('click', '.al-add-multi', function () {
      var frame = wp.media({ title: 'اختر الشعارات', multiple: 'add', library: { type: 'image' } });
      frame.on('select', function () {
        frame.state().get('selection').each(function (a) {
          var n = $list.children().length, $li = $(tpl.replace(/__i__/g, n));
          $li.find('.al-img-url').val(a.attributes.url); $li.find('img').attr('src', a.attributes.url);
          $li.find('input[name$="[name_en]"]').val(a.attributes.alt || a.attributes.title || '');
          $list.append($li);
        });
        reindex();
      });
      frame.open();
    });
  });
});
