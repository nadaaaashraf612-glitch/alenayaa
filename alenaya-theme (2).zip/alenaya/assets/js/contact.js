(function () {
  var form = document.getElementById('enquiry-form'), box = document.getElementById('form-status');
  if (!form) return;
  var params = new URLSearchParams(location.search);
  if (box && params.has('al_sent') && params.get('al_sent') === '1') { box.classList.add('show'); }
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var btn = form.querySelector('button[type=submit]'), label = btn ? btn.innerHTML : '';
    if (btn) { btn.disabled = true; btn.textContent = ALData.sending; }
    var fd = new FormData(form); fd.append('al_ajax', '1');
    fetch(ALData.ajax, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
      .then(function (r) { return r.json().catch(function () { return { ok: false, message: ALData.error }; }); })
      .then(function (j) {
        if (box) { box.textContent = j.message || ''; box.classList.add('show'); box.style.color = j.ok ? '' : '#b42318'; box.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }
        if (j.ok) form.reset();
      })
      .catch(function () { if (box) { box.textContent = ALData.error; box.classList.add('show'); box.style.color = '#b42318'; } })
      .then(function () { if (btn) { btn.disabled = false; btn.innerHTML = label; } });
  });
})();
