(function () {
  var d = document, w = window;
  var header = d.querySelector('.site-header');
  var upd = function () { if (header) header.classList.toggle('scrolled', w.scrollY > 40); };
  upd(); w.addEventListener('scroll', upd, { passive: true });

  d.querySelectorAll('[data-lang]').forEach(function (b) {
    b.addEventListener('click', function () {
      var u = new URL(w.location.href); u.searchParams.set('lang', b.getAttribute('data-lang')); w.location.href = u.toString();
    });
  });

  var mb = d.querySelector('.menu-btn'), links = d.querySelector('.nav-links');
  if (mb && links) {
    mb.addEventListener('click', function () { var o = links.classList.toggle('is-open'); mb.setAttribute('aria-expanded', o ? 'true' : 'false'); });
    links.addEventListener('click', function (e) { if (e.target.closest('a')) { links.classList.remove('is-open'); mb.setAttribute('aria-expanded', 'false'); } });
  }

  var toggle = d.querySelector('.nav-search-toggle'), panel = d.querySelector('.nav-search-panel');
  if (toggle && panel) {
    var input = panel.querySelector('input[type=search]'), items = [].slice.call(panel.querySelectorAll('.nav-search-result')), empty = panel.querySelector('.nav-search-empty');
    var close = function () { panel.hidden = true; toggle.setAttribute('aria-expanded', 'false'); };
    toggle.addEventListener('click', function () {
      var open = panel.hidden; panel.hidden = !open; toggle.setAttribute('aria-expanded', String(open));
      if (open && input) { input.focus(); input.select(); }
    });
    if (input) input.addEventListener('input', function () {
      var q = input.value.trim().toLowerCase(), n = 0;
      items.forEach(function (it) { var show = !q || (it.getAttribute('data-search') || '').indexOf(q) > -1 || it.textContent.toLowerCase().indexOf(q) > -1; it.hidden = !show; if (show) n++; });
      if (empty) empty.classList.toggle('visible', n === 0 && q.length > 0);
    });
    d.addEventListener('click', function (e) { if (!panel.hidden && !e.target.closest('.nav-search-panel') && !e.target.closest('.nav-search-toggle')) close(); });
    d.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
  }

  if (!w.__alRevealHandled && 'IntersectionObserver' in w) {
    var reduced = w.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var els = d.querySelectorAll('.reveal');
    if (reduced) { els.forEach(function (el) { el.classList.add('visible'); }); }
    else {
      var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('visible'); io.unobserve(e.target); } }); }, { threshold: .12 });
      els.forEach(function (el) { io.observe(el); });
    }
  }
})();
