(function () {
  var filters = document.querySelectorAll('.filter'), cards = document.querySelectorAll('.client-card');
  filters.forEach(function (button) {
    button.addEventListener('click', function () {
      filters.forEach(function (i) { i.classList.remove('active'); });
      button.classList.add('active');
      var v = button.getAttribute('data-filter');
      cards.forEach(function (c) { c.hidden = !(v === 'all' || c.getAttribute('data-sector') === v); });
    });
  });
})();
