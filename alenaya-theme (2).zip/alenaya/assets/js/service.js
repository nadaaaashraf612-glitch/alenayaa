(function () {
  var lb = document.getElementById('service-gallery-lightbox'), big = document.getElementById('service-gallery-large'), grid = document.getElementById('service-gallery-grid');
  if (!lb || !big || !grid) return;
  grid.addEventListener('click', function (e) {
    var it = e.target.closest('.service-gallery-item'); if (!it) return;
    big.style.setProperty('--img', 'url(' + it.getAttribute('data-img') + ')'); lb.classList.add('open'); document.body.style.overflow = 'hidden';
  });
  var close = function () { lb.classList.remove('open'); document.body.style.overflow = ''; };
  var x = lb.querySelector('.service-gallery-close'); if (x) x.addEventListener('click', close);
  lb.addEventListener('click', function (e) { if (e.target === lb) close(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
})();
