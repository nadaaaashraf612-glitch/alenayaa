(function(){

    document.querySelectorAll('.profile-copy .section-title,.cert-head .section-title,.features-head .section-title').forEach(title=>{if(title.querySelector('.title-accent-blue'))return;const words=title.textContent.trim().split(/\s+/);if(words.length<3)return;const accent=words.splice(-2).join(' ');title.innerHTML=`${words.join(' ')} <span class="title-accent-blue">${accent}</span>`});
const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;window.__alRevealHandled=true;
    if(!reduced){const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.animate([{opacity:.15,transform:'translateY(28px)'},{opacity:1,transform:'translateY(0)'}],{duration:780,easing:'cubic-bezier(.2,.8,.2,1)',fill:'both'});io.unobserve(e.target)}}),{threshold:.14});document.querySelectorAll('.reveal').forEach(el=>io.observe(el))}
  
})();
