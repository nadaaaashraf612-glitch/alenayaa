<?php
if (!defined('ABSPATH')) { exit; }
al_set_header_variant('internal');
the_post();
$id = get_the_ID();
$title = al_post_field($id, 'title');
$work = isset($_GET['work']) ? (int) $_GET['work'] : 0;
if ($work >= 1 && $work <= 6) {
    // ---- sample "selected work" project view
    $cells = al_gallery_urls($id, $work, 5);
    $loc = al_t('single.work' . $work . '.city');
    $svc = $title;
    get_header();
    get_template_part('template-parts/project-view', null, array(
        'title' => al_t('single.work' . $work . '.title'), 'location' => $loc . ', ' . al_tr('global.footer.address'),
        'year_label' => al_t('single.project.completed') . ' ' . al_t('single.work' . $work . '.year'),
        'back_url' => get_permalink($id), 'back_label' => $title, 'hero_img' => $cells[0],
        'desc' => al_tr('single.project.sample_desc', array('t' => mb_strtolower($svc), 'p' => mb_strtolower(al_t('single.work' . $work . '.title')))),
        'overview_title' => al_tr('single.project.overview_sample', array('t' => $svc)),
        'fact_year' => al_t('single.work' . $work . '.year'), 'fact_location' => $loc, 'fact_duration' => al_t('single.work' . $work . '.duration'), 'fact_service' => $svc,
        'gallery' => $cells, 'map_q' => al_t('single.work' . $work . '.city', 'en') . ', Saudi Arabia',
    ));
    get_footer();
    return;
}
$intro = al_post_field($id, 'excerpt');
$desc = wp_strip_all_tags(al_post_field($id, 'desc'));
$img = al_post_image_url($id, 'full');
$steps = al_post_field($id, 'steps');
if (!$steps) { $steps = array(); }
$gallery = al_gallery_urls($id, 0, 5);
get_header();
?>
<main>
<section class="detail-hero" id="hero" style="--img:url(<?php echo esc_url($img); ?>)"><div class="shell hero-content">
<div class="breadcrumbs"><a href="<?php echo esc_url(al_url('services')); ?>"><?php al_e('single.service.crumb'); ?></a><span>/</span><span id="crumb"><?php echo esc_html($title); ?></span></div>
<h1 id="service-title"><?php echo esc_html($title); ?></h1>
<p id="service-intro"><?php echo esc_html($intro); ?></p>
</div></section>
<section class="overview"><div class="shell overview-grid"><div class="overview-copy"><p class="eyebrow"><?php al_e('single.service.overview'); ?></p>
<h2 class="section-title" id="overview-title"><?php echo esc_html(al_tr('single.service.overview_title', array('t' => al_lang() === 'ar' ? $title : mb_strtolower($title)))); ?></h2>
<p id="service-description"><?php echo esc_html($desc); ?></p></div>
<div aria-label="Service execution" class="overview-image" id="overview-image" role="img" style="--img:url(<?php echo esc_url($img); ?>)"></div></div></section>
<section aria-labelledby="service-gallery-title" class="service-gallery"><div class="shell"><div class="service-gallery-head"><p class="eyebrow"><?php al_e('single.service.gallery_eyebrow'); ?></p><h2 class="section-title" id="service-gallery-title"><?php al_e('single.service.gallery_title'); ?></h2></div>
<div class="service-gallery-grid" id="service-gallery-grid"><?php foreach ($gallery as $i => $u) : ?><button class="service-gallery-item" type="button" style="--img:url(<?php echo esc_url($u); ?>)" data-img="<?php echo esc_url($u); ?>" aria-label="<?php echo esc_attr($title . ' ' . ($i + 1)); ?>"></button><?php endforeach; ?></div></div></section>
<section class="projects-gallery"><div class="shell"><div class="gallery-head"><p class="eyebrow"><?php al_e('single.service.works_eyebrow'); ?></p><h2 class="section-title"><?php al_e('single.service.works_title'); ?></h2></div>
<div class="project-grid" id="project-gallery">
<?php $wg = al_gallery_urls($id, 0, 11); for ($n = 1; $n <= 6; $n++) : ?>
<a class="project-card" data-project="<?php echo $n - 1; ?>" href="<?php echo esc_url(add_query_arg('work', $n, get_permalink($id))); ?>"><div class="project-image" style="--img:url(<?php echo esc_url($wg[$n % count($wg)]); ?>)"></div><div class="project-info"><div><h3><?php al_e('single.work' . $n . '.title'); ?></h3><span class="project-location"><?php echo al_pin_svg(); ?><?php echo esc_html(al_t('single.work' . $n . '.city') . ', ' . al_tr('global.footer.address')); ?></span></div><span class="project-no">0<?php echo $n; ?></span><span class="view-project"><?php al_e('single.service.view_project'); ?></span></div></a>
<?php endfor; ?>
</div></div></section>
<section class="process"><div class="shell"><div class="process-head"><p class="eyebrow"><?php al_e('single.service.process_eyebrow'); ?></p><h2 class="section-title"><?php al_e('single.service.process_title'); ?></h2></div>
<div class="steps" id="steps"><?php foreach ($steps as $i => $st) : ?><article class="step"><span class="step-number">0<?php echo $i + 1; ?></span><span class="step-icon"><svg viewBox="0 0 24 24"><path d="m5 12 4 4L19 6"/></svg></span><h3><?php echo esc_html($st); ?></h3><p><?php al_e('single.service.step_text'); ?></p></article><?php endforeach; ?></div></div></section>
<section class="service-cta"><div class="shell"><div class="cta-panel"><h2><?php al_e('single.service.cta'); ?></h2><a class="btn" href="<?php echo esc_url(al_url('contact')); ?>"><?php al_e('single.service.cta_btn'); ?></a></div></div></section>
</main>
<div class="service-gallery-lightbox" id="service-gallery-lightbox" role="dialog" aria-modal="true" aria-label="Image preview"><button class="service-gallery-close" type="button" aria-label="Close">×</button><div class="service-gallery-large" id="service-gallery-large"></div></div>
<?php get_footer(); ?>
