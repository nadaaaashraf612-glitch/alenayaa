<?php
if (!defined('ABSPATH')) { exit; }
al_set_header_variant('internal');
the_post();
$id = get_the_ID();
$terms = get_the_terms($id, 'project_category');
$term = ($terms && !is_wp_error($terms)) ? array_values($terms)[0] : null;
$title = al_post_field($id, 'title');
$loc = al_post_field($id, 'location');
$loc_en = get_post_meta($id, 'al_location', true);
get_header();
get_template_part('template-parts/project-view', null, array(
    'title' => $title, 'location' => $loc, 'year_label' => al_t('single.project.portfolio_label'),
    'back_url' => $term ? get_term_link($term) : al_url('projects'), 'back_label' => al_t('single.project.crumb_category'),
    'hero_img' => al_post_image_url($id, 'full'), 'desc' => al_post_field($id, 'excerpt'),
    'overview_title' => al_t('single.project.overview_portfolio'),
    'fact_year' => al_t('single.project.completed'), 'fact_location' => $loc, 'fact_duration' => al_t('single.project.private'),
    'fact_service' => $term ? al_term_field($term, 'name') : '', 'gallery' => get_post_meta($id, 'al_gallery', true) ? al_gallery_urls($id, 0, 5) : null,
    'map_q' => ($loc_en ? $loc_en : $title) . ', Saudi Arabia',
));
get_footer();
