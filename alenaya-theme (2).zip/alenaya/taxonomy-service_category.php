<?php
if (!defined('ABSPATH')) { exit; }
wp_safe_redirect(al_url('services') . '#services'); exit;
