<?php
/**
 * Al-Enaya theme bootstrap.
 */
if (!defined('ABSPATH')) { exit; }

define('AL_DIR', get_template_directory());
define('AL_URI', get_template_directory_uri());
define('AL_VERSION', '1.0.0');

require_once AL_DIR . '/inc/helpers.php';
require_once AL_DIR . '/inc/cpt.php';
require_once AL_DIR . '/inc/render.php';
require_once AL_DIR . '/inc/forms.php';
require_once AL_DIR . '/inc/seed.php';
if (is_admin()) { require_once AL_DIR . '/inc/admin.php'; }

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
    load_theme_textdomain('alenaya', AL_DIR . '/languages');
});

/** Which page stylesheet belongs to the current request */
function al_page_css_name() {
    if (is_front_page()) { return 'home'; }
    if (is_singular('service')) { return (isset($_GET['work']) && (int) $_GET['work'] >= 1) ? 'project-single' : 'service-single'; }
    if (is_singular('project')) { return 'project-single'; }
    if (is_tax('project_category')) { return 'project-category'; }
    if (is_tax('service_category')) { return 'services'; }
    if (is_page()) {
        $tpl = basename((string) get_page_template_slug(), '.php');
        $map = array('page-about' => 'about', 'page-services' => 'services', 'page-projects' => 'projects', 'page-clients' => 'clients', 'page-certifications' => 'certifications', 'page-contact' => 'contact', 'page-faq' => 'faq', 'page-privacy' => 'privacy');
        if (isset($map[$tpl])) { return $map[$tpl]; }
    }
    return 'faq';
}

add_action('wp_enqueue_scripts', function () {
    $rtl = al_is_rtl() ? '-rtl' : '';
    wp_enqueue_style('al-fonts', 'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Cairo:wght@400;500;600;700;800&display=swap', array(), null);
    wp_enqueue_style('al-shared', AL_URI . '/assets/css/shared' . $rtl . '.css', array('al-fonts'), AL_VERSION);
    $page = al_page_css_name();
    wp_enqueue_style('al-page', AL_URI . '/assets/css/' . $page . $rtl . '.css', array('al-shared'), AL_VERSION);
    $deps = array('al-page');
    if (al_header_variant() === 'internal') {
        wp_enqueue_style('al-nav', AL_URI . '/assets/css/internal-nav' . $rtl . '.css', array('al-page'), AL_VERSION);
        $deps = array('al-nav');
    }
    wp_enqueue_style('al-overrides', AL_URI . '/assets/css/overrides' . $rtl . '.css', $deps, AL_VERSION);

    $js = array();
    if (is_front_page()) {
        wp_enqueue_script('al-gsap', 'https://cdn.jsdelivr.net/npm/gsap@3.13.0/dist/gsap.min.js', array(), '3.13.0', true);
        wp_enqueue_script('al-st', 'https://cdn.jsdelivr.net/npm/gsap@3.13.0/dist/ScrollTrigger.min.js', array('al-gsap'), '3.13.0', true);
        $js['home'] = array('al-st');
    }
    if ($page === 'about') { $js['about'] = array(); }
    if ($page === 'clients') { $js['clients'] = array(); }
    if ($page === 'contact') { $js['contact'] = array(); }
    if ($page === 'service-single') { $js['service'] = array(); }
    wp_enqueue_script('al-site', AL_URI . '/assets/js/site.js', array(), AL_VERSION, true);
    wp_localize_script('al-site', 'ALData', array('ajax' => admin_url('admin-post.php'), 'lang' => al_lang(), 'sending' => wp_strip_all_tags(al_t('single.form.sending')), 'error' => wp_strip_all_tags(al_t('single.form.error'))));
    foreach ($js as $name => $deps2) {
        wp_enqueue_script('al-' . $name, AL_URI . '/assets/js/' . $name . '.js', array_merge(array('al-site'), $deps2), AL_VERSION, true);
    }
}, 20);

add_filter('body_class', function ($c) {
    $c[] = al_is_rtl() ? 'al-rtl' : 'al-ltr';
    if (is_singular('project') && !isset($_GET['work'])) { $c[] = 'portfolio-project'; }
    if (is_front_page()) { $c[] = 'home'; }
    return array_unique($c);
});

/* Document title (language aware) */
add_filter('document_title_parts', function ($p) {
    $site = al_lang() === 'ar' ? 'العناية' : 'AL-ENAYA';
    if (is_singular(array('service', 'project'))) { $p['title'] = al_post_field(get_the_ID(), 'title'); }
    elseif (is_tax(array('project_category', 'service_category'))) { $p['title'] = al_term_field(get_queried_object(), 'name'); }
    elseif (is_page() && strpos($p['title'], ' — ') !== false) {
        $parts = explode(' — ', $p['title']);
        $p['title'] = al_lang() === 'ar' ? trim(end($parts)) : trim($parts[0]);
    }
    $p['site'] = $site;
    unset($p['tagline']);
    return $p;
});
add_filter('document_title_separator', function () { return '|'; });

/* Vary cache by language cookie */
add_action('send_headers', function () { if (!is_admin()) { header('Vary: Cookie', false); } });

/* Admin: prevent the page editor from hiding theme templates */
add_filter('theme_page_templates', function ($t) { return $t; });

/* Disable emoji scripts (performance) */
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
