<?php
/**
 * Template Name: Al-Enaya Privacy
 * Generated from the original Al-Enaya static design.
 */
al_set_header_variant('internal');
get_header();
?>
<main class="legal-main"><section class="legal-hero"><div class="shell legal-hero-inner"><h1><?php al_e('privacy.legal-hero.1'); ?></h1><p><?php al_e('privacy.legal-hero.2'); ?></p></div></section><div class="shell"><div class="policy"><section><h2><?php al_e('privacy.section.1'); ?></h2><p><?php al_e('privacy.section.2'); ?></p></section><section><h2><?php al_e('privacy.section2.1'); ?></h2><p><?php al_e('privacy.section2.2'); ?></p></section><section><h2><?php al_e('privacy.section3.1'); ?></h2><p><?php al_e('privacy.section3.2'); ?></p></section><section><h2><?php al_e('privacy.section4.1'); ?></h2><p><?php al_e('privacy.section4.2'); ?></p></section></div></div></main>
<?php get_footer(); ?>
