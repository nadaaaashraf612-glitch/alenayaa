<?php
/**
 * Template Name: Al-Enaya Projects
 * Generated from the original Al-Enaya static design.
 */
al_set_header_variant('home');
get_header();
?>
<main><section class="hero" style="--hero-img:url(<?php echo esc_url(al_img('projects.hero.bg')); ?>);"><div class="shell hero-content"><p class="eyebrow"><?php al_e('projects.hero.1'); ?></p><h1><?php al_e('projects.hero.2'); ?> <span><?php al_e('projects.hero.3'); ?></span></h1></div><div class="hero-line"></div></section>
<section class="categories"><div class="shell"><div class="section-head"><p class="eyebrow"><?php al_e('projects.categories.1'); ?></p><h2><?php al_e('projects.categories.2'); ?></h2></div><div class="category-grid"><?php al_render_project_categories(); ?></div></div></section></main>
<?php get_footer(); ?>
