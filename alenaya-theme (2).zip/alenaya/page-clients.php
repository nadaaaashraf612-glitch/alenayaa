<?php
/**
 * Template Name: Al-Enaya Clients
 * Generated from the original Al-Enaya static design.
 */
al_set_header_variant('internal');
get_header();
?>
<main><section class="hero" style="--hero-img:url(<?php echo esc_url(al_img('clients.hero.bg')); ?>);"><div class="shell hero-content"><p class="eyebrow"><?php al_e('clients.hero.1'); ?></p><h1><span><?php al_e('clients.hero.2'); ?></span><span><?php al_e('clients.hero.3'); ?></span></h1></div><div aria-hidden="true" class="hero-line"></div></section><section class="clients"><div class="shell"><div class="section-head"><div><p class="eyebrow"><?php al_e('clients.clients.1'); ?></p><h2><?php al_e('clients.clients.2'); ?></h2></div><p><?php al_e('clients.clients.3'); ?></p></div><div aria-label="Filter clients" class="filters" role="group"><button class="filter active" data-filter="all"><?php al_e('clients.clients.4'); ?></button><button class="filter" data-filter="religious"><?php al_e('clients.clients.5'); ?></button><button class="filter" data-filter="residential"><?php al_e('clients.clients.6'); ?></button><button class="filter" data-filter="corporate"><?php al_e('clients.clients.7'); ?></button><button class="filter" data-filter="hospitality"><?php al_e('clients.clients.8'); ?></button></div><div class="client-grid" id="client-grid"><?php al_render_client_cards(); ?></div></div></section></main>
<?php get_footer(); ?>
