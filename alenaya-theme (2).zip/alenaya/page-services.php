<?php
/**
 * Template Name: Al-Enaya Services
 * Generated from the original Al-Enaya static design.
 */
al_set_header_variant('home');
get_header();
?>
<main>
<section class="page-hero" style="--img:url(<?php echo esc_url(al_img('services.hero.bg')); ?>)"><div class="shell hero-content"><p class="eyebrow"><?php al_e('services.page-hero.1'); ?></p><h1><?php al_e('services.page-hero.2'); ?> <span><?php al_e('services.page-hero.3'); ?></span></h1></div></section>
<section class="services" id="services"><div class="shell"><div class="services-head"><p class="eyebrow"><?php al_e('services.services.1'); ?></p><h2 class="section-title"><?php al_e('services.services.2'); ?></h2></div><div class="services-tabs"><?php al_render_services_tabs(array('mode'=>'archive')); ?></div></div></section>
</main>
<?php get_footer(); ?>
