<?php
if (!defined('ABSPATH')) { exit; }
al_set_header_variant('internal');
$q = get_search_query();
$found = array();
global $wp_query;
foreach ($wp_query->posts as $p) { $found[$p->ID] = $p; }
if ($q !== '') { foreach (al_search_extra_ids($q) as $pid) { if (!isset($found[$pid])) { $found[$pid] = get_post($pid); } } }
get_header();
?>
<main class="legal-main">
<section class="legal-hero"><div class="shell legal-hero-inner"><h1><?php al_e('single.search.title'); ?> “<?php echo esc_html($q); ?>”</h1></div></section>
<div class="shell al-results">
<?php if ($found) : foreach ($found as $p) :
    $type = get_post_type($p);
    $t = in_array($type, array('service', 'project'), true) ? al_post_field($p->ID, 'title') : preg_replace('/^.*? — /u', '', get_the_title($p));
    $ex = in_array($type, array('service', 'project'), true) ? al_post_field($p->ID, 'excerpt') : '';
    if ($type === 'page' && al_lang() !== 'ar') { $t = preg_replace('/ — .*$/u', '', get_the_title($p)); } ?>
    <a class="al-result" href="<?php echo esc_url(get_permalink($p)); ?>"><h3><?php echo esc_html($t); ?></h3><?php if ($ex) { echo '<p>' . esc_html($ex) . '</p>'; } ?></a>
<?php endforeach; else : ?>
    <div class="al-none"><h3><?php al_e('single.search.none'); ?></h3><p><?php al_e('single.search.hint'); ?></p></div>
<?php endif; ?>
</div></main>
<?php get_footer(); ?>
