<?php
/**
 * Project detail view (used by single-project.php and by the sample works of single-service.php).
 * $args: title, location, year_label, service_name, back_url, back_label, hero_img, desc, overview_title,
 *        fact_year, fact_location, fact_duration, fact_service, gallery (array|null), map_q
 */
if (!defined('ABSPATH')) { exit; }
$a = $args;
$ic = array(
 'year' => '<svg viewBox="0 0 24 24"><rect height="16" rx="2" width="18" x="3" y="5"></rect><path d="M16 3v4M8 3v4M3 10h18"></path></svg>',
 'loc' => '<svg viewBox="0 0 24 24"><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"></path><circle cx="12" cy="10" r="2.5"></circle></svg>',
 'dur' => '<svg viewBox="0 0 24 24"><circle cx="12" cy="13" r="8"></circle><path d="M12 9v4l3 2M9 2h6"></path></svg>',
 'svc' => '<svg viewBox="0 0 24 24"><path d="M4 7h16v13H4zM8 7V4h8v3M4 12h16M10 12v2h4v-2"></path></svg>',
);
?>
<main>
<section class="project-hero" id="project-hero" style="--img:url(<?php echo esc_url($a['hero_img']); ?>)"><div class="shell hero-content">
<div class="breadcrumbs"><a href="<?php echo esc_url(al_url('services')); ?>"><?php al_e('single.project.crumb_services'); ?></a><span>/</span><a href="<?php echo esc_url($a['back_url']); ?>"><?php echo esc_html($a['back_label']); ?></a><span>/</span><span><?php al_e('single.project.crumb_project'); ?></span></div>
<h1><?php echo esc_html($a['title']); ?></h1>
<div class="hero-meta"><span><i></i><b><?php echo esc_html($a['location']); ?></b></span><span><i></i><b><?php echo esc_html($a['year_label']); ?></b></span></div>
</div></section>
<section class="project-overview"><div class="shell overview-grid"><div class="project-copy"><p class="eyebrow"><?php al_e('single.project.overview_eyebrow'); ?></p><h2 class="section-title"><?php echo esc_html($a['overview_title']); ?></h2><p><?php echo esc_html($a['desc']); ?></p></div>
<div class="facts">
<div class="fact"><span aria-hidden="true" class="fact-icon"><?php echo $ic['year']; ?></span><small><?php al_e('single.project.fact_year'); ?></small><strong class="accent"><?php echo esc_html($a['fact_year']); ?></strong></div>
<div class="fact"><span aria-hidden="true" class="fact-icon"><?php echo $ic['loc']; ?></span><small><?php al_e('single.project.fact_location'); ?></small><strong><?php echo esc_html($a['fact_location']); ?></strong></div>
<div class="fact"><span aria-hidden="true" class="fact-icon"><?php echo $ic['dur']; ?></span><small><?php al_e('single.project.fact_duration'); ?></small><strong><?php echo esc_html($a['fact_duration']); ?></strong></div>
<div class="fact"><span aria-hidden="true" class="fact-icon"><?php echo $ic['svc']; ?></span><small><?php al_e('single.project.fact_service'); ?></small><strong><?php echo esc_html($a['fact_service']); ?></strong></div>
</div></div></section>
<section class="scope"><div class="shell"><div class="scope-head"><p class="eyebrow"><?php al_e('single.project.scope_eyebrow'); ?></p><h2 class="section-title"><?php al_e('single.project.scope_title'); ?></h2></div>
<div class="scope-grid">
<?php for ($i = 1; $i <= 4; $i++) : ?>
<article class="scope-item"><span>0<?php echo $i; ?></span><h3><?php al_e('single.scope' . $i . '.title'); ?></h3><p><?php al_e('single.project.scope_text'); ?></p></article>
<?php endfor; ?>
</div></div></section>
<?php if (!empty($a['gallery'])) : ?>
<section class="project-gallery"><div class="shell"><div class="gallery-head"><p class="eyebrow"><?php al_e('single.project.gallery_eyebrow'); ?></p><h2 class="section-title"><?php al_e('single.project.gallery_title'); ?></h2></div>
<div class="gallery-grid"><?php foreach ($a['gallery'] as $u) : ?><div class="gallery-image" style="--img:url(<?php echo esc_url($u); ?>)"></div><?php endforeach; ?></div></div></section>
<?php endif; ?>
<section class="location"><div class="shell location-grid"><div class="location-copy"><p class="eyebrow"><?php al_e('single.project.map_eyebrow'); ?></p><h2 class="section-title"><?php echo esc_html($a['location']); ?></h2><p><?php al_e('single.project.map_text'); ?></p><span class="address"><?php echo esc_html($a['location']); ?></span></div>
<div class="map"><iframe loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="Project location" src="<?php echo esc_url(al_map_embed_url($a['map_q'])); ?>"></iframe></div></div></section>
<section aria-labelledby="project-cta-title" class="project-cta"><div class="shell"><div class="project-cta-panel"><div class="project-cta-copy"><p class="eyebrow"><?php al_e('single.project.cta_eyebrow'); ?></p><h2 id="project-cta-title"><span><?php al_e('single.project.cta_l1'); ?></span><span><?php al_e('single.project.cta_l2'); ?></span></h2><p><?php al_e('single.project.cta_text'); ?></p></div><a class="btn" href="<?php echo esc_url(al_url('contact')); ?>"><?php al_e('single.project.cta_btn'); ?></a></div></div></section>
</main>
