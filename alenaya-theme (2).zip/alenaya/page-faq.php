<?php
/**
 * Template Name: Al-Enaya FAQ
 * Generated from the original Al-Enaya static design.
 */
al_set_header_variant('internal');
get_header();
?>
<main class="legal-main"><section class="legal-hero"><div class="shell legal-hero-inner"><h1><?php al_e('faq.legal-hero.1'); ?></h1><p><?php al_e('faq.legal-hero.2'); ?></p></div></section><div class="shell"><div class="faq"><details open=""><summary><?php al_e('faq.legal-main.1'); ?></summary><p><?php al_e('faq.legal-main.2'); ?></p></details><details><summary><?php al_e('faq.legal-main.3'); ?></summary><p><?php al_e('faq.legal-main.4'); ?></p></details><details><summary><?php al_e('faq.legal-main.5'); ?></summary><p><?php al_e('faq.legal-main.6'); ?></p></details><details><summary><?php al_e('faq.legal-main.7'); ?></summary><p><?php al_e('faq.legal-main.8'); ?></p></details></div></div></main>
<?php get_footer(); ?>
