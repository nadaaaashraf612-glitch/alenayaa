<?php
/**
 * Theme control panel: organised, bilingual (AR/EN) editing of every text and image.
 */
if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', 'al_admin_menu');
function al_admin_menu() {
    add_menu_page('إعدادات العناية', 'إعدادات العناية', 'manage_options', 'alenaya', 'al_page_overview', 'dashicons-admin-customizer', 3);
    add_submenu_page('alenaya', 'نظرة عامة', 'نظرة عامة', 'manage_options', 'alenaya', 'al_page_overview');
    add_submenu_page('alenaya', 'الإعدادات العامة', 'الإعدادات العامة', 'manage_options', 'alenaya-settings', 'al_page_settings');
    foreach (al_defaults()['pages'] as $slug => $def) {
        add_submenu_page('alenaya', $def['title'], $def['title'], 'manage_options', 'alenaya-' . $slug, function () use ($slug) { al_page_content($slug); });
    }
    add_submenu_page('alenaya', 'شعارات وبطاقات العملاء', 'شعارات وبطاقات العملاء', 'manage_options', 'alenaya-logos', 'al_page_logos');
    add_submenu_page('alenaya', 'دليل البريد والإضافات', 'دليل البريد والإضافات', 'manage_options', 'alenaya-guide', 'al_page_guide');
}

add_action('admin_enqueue_scripts', function ($hook) {
    if (strpos($hook, 'alenaya') === false) { return; }
    wp_enqueue_media();
    wp_enqueue_script('jquery-ui-sortable');
    wp_enqueue_style('al-admin', AL_URI . '/assets/css/admin.css', array(), AL_VERSION);
    wp_enqueue_script('al-admin', AL_URI . '/assets/js/admin.js', array('jquery', 'jquery-ui-sortable'), AL_VERSION, true);
});

function al_admin_notice() {
    if (!empty($_GET['saved'])) { echo '<div class="notice notice-success is-dismissible"><p>تم الحفظ بنجاح ✔</p></div>'; }
    if (!empty($_GET['reset'])) { echo '<div class="notice notice-warning is-dismissible"><p>تمت إعادة المحتوى الافتراضي لهذه الصفحة.</p></div>'; }
}

/* ------------------------------------------------------------- overview */
function al_page_overview() {
    $pages = al_defaults()['pages'];
    ?>
    <div class="wrap al-wrap" dir="rtl">
        <h1>لوحة تحكم موقع العناية</h1>
        <p class="al-lead">من هنا تتحكم في كل كلمة وصورة في الموقع، بالعربية والإنجليزية. الأقسام مرتبة بنفس ترتيب ظهورها في الصفحات.</p>
        <div class="al-cards">
            <?php foreach ($pages as $slug => $def) : ?>
                <a class="al-card" href="<?php echo esc_url(admin_url('admin.php?page=alenaya-' . $slug)); ?>"><strong><?php echo esc_html($def['title']); ?></strong><span><?php echo count($def['groups']); ?> أقسام</span></a>
            <?php endforeach; ?>
            <a class="al-card" href="<?php echo esc_url(admin_url('edit.php?post_type=service')); ?>"><strong>الخدمات / Services</strong><span>إضافة · حذف · ترتيب</span></a>
            <a class="al-card" href="<?php echo esc_url(admin_url('edit-tags.php?taxonomy=service_category&post_type=service')); ?>"><strong>تصنيفات الخدمات</strong><span>إضافة · حذف · ترتيب</span></a>
            <a class="al-card" href="<?php echo esc_url(admin_url('edit.php?post_type=project')); ?>"><strong>المشاريع / Projects</strong><span>إضافة · حذف · ترتيب</span></a>
            <a class="al-card" href="<?php echo esc_url(admin_url('edit-tags.php?taxonomy=project_category&post_type=project')); ?>"><strong>تصنيفات المشاريع</strong><span>إضافة · حذف · ترتيب</span></a>
            <a class="al-card" href="<?php echo esc_url(admin_url('admin.php?page=alenaya-logos')); ?>"><strong>شعارات العملاء</strong><span>إضافة · حذف · ترتيب</span></a>
            <a class="al-card" href="<?php echo esc_url(admin_url('edit.php?post_type=al_enquiry')); ?>"><strong>رسائل الاستفسارات</strong><span>كل رسائل النموذج محفوظة هنا</span></a>
            <a class="al-card" href="<?php echo esc_url(admin_url('admin.php?page=alenaya-settings')); ?>"><strong>الإعدادات العامة</strong><span>واتساب · الإيميل · SMTP · اللغة</span></a>
            <a class="al-card" href="<?php echo esc_url(admin_url('admin.php?page=alenaya-guide')); ?>"><strong>دليل البريد والإضافات</strong><span>خطوات الربط</span></a>
        </div>
        <h2>قائمة مراجعة سريعة</h2>
        <ol class="al-check">
            <li>اضبط رقم الواتساب والبريد المستقبل للنماذج من «الإعدادات العامة».</li>
            <li>فعّل الإرسال عبر SMTP (إعدادات الثيم أو إضافة WP Mail SMTP) لضمان وصول الرسائل لصندوق الوارد.</li>
            <li>من «الإعدادات ← الدوائم (Permalinks)» اضغط «حفظ التغييرات» مرة واحدة بعد تفعيل الثيم.</li>
            <li>أضف شعارات العملاء من «شعارات وبطاقات العملاء».</li>
        </ol>
    </div>
    <?php
}

/* ------------------------------------------------------------- content pages */
function al_render_field($key, $f, $st) {
    $en = isset($st[$key]['en']) ? $st[$key]['en'] : $f['en'];
    $ar = isset($st[$key]['ar']) ? $st[$key]['ar'] : $f['ar'];
    echo '<div class="al-row al-type-' . esc_attr($f['type']) . '"><div class="al-meta"><b>' . esc_html($f['label']) . '</b><code>' . esc_html($key) . '</code></div>';
    if ($f['type'] === 'image') {
        $cur = !empty($st[$key]['en']) ? $st[$key]['en'] : AL_URI . '/assets/' . $f['en'];
        echo '<div class="al-img"><img src="' . esc_url($cur) . '" alt=""><div><input type="text" class="al-img-url" name="al[' . esc_attr($key) . '][en]" value="' . esc_attr(!empty($st[$key]['en']) ? $st[$key]['en'] : '') . '" placeholder="الصورة الافتراضية للتصميم — اختر صورة لتغييرها"><button type="button" class="button al-pick">اختيار صورة</button> <button type="button" class="button al-unpick">استعادة الافتراضية</button></div></div></div>';
        return;
    }
    echo '<div class="al-cols"><label><span>EN</span>';
    if ($f['type'] === 'textarea') { echo '<textarea rows="3" name="al[' . esc_attr($key) . '][en]" dir="ltr">' . esc_textarea($en) . '</textarea>'; }
    else { echo '<input type="text" name="al[' . esc_attr($key) . '][en]" value="' . esc_attr($en) . '" dir="ltr">'; }
    echo '</label><label><span>AR</span>';
    if ($f['type'] === 'textarea') { echo '<textarea rows="3" name="al[' . esc_attr($key) . '][ar]" dir="rtl">' . esc_textarea($ar) . '</textarea>'; }
    else { echo '<input type="text" name="al[' . esc_attr($key) . '][ar]" value="' . esc_attr($ar) . '" dir="rtl">'; }
    echo '</label></div></div>';
}

function al_page_content($slug) {
    $defs = al_defaults();
    if (!isset($defs['pages'][$slug])) { return; }
    $page = $defs['pages'][$slug];
    $st = al_store();
    ?>
    <div class="wrap al-wrap" dir="rtl">
        <h1><?php echo esc_html($page['title']); ?></h1>
        <?php al_admin_notice(); ?>
        <p class="al-lead">الأقسام أدناه بنفس ترتيب ظهورها في الصفحة. يمكنك استخدام الوسوم <code>&lt;br&gt;</code> لسطر جديد. اترك حقل العربي فارغاً ليظهر النص الإنجليزي.</p>
        <?php if ($slug === 'home') : ?>
            <p class="al-note">ملاحظة: قسم <b>الخدمات</b> في الرئيسية يعرض الخدمات من «الخدمات» (يمكنك تحديد عدد المعروض من «الإعدادات العامة»)، وقسم <b>العملاء</b> يعرض الشعارات من «شعارات وبطاقات العملاء».</p>
        <?php endif; ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="alenaya_save_content">
            <input type="hidden" name="al_page" value="<?php echo esc_attr($slug); ?>">
            <?php wp_nonce_field('alenaya_save_content', 'al_admin_nonce'); ?>
            <?php foreach ($page['groups'] as $g) : ?>
                <details class="al-group" open>
                    <summary><?php echo esc_html($g[0]); ?> <small>(<?php echo count($g[1]); ?>)</small></summary>
                    <?php foreach ($g[1] as $key) { if (isset($defs['fields'][$key])) { al_render_field($key, $defs['fields'][$key], $st); } } ?>
                </details>
            <?php endforeach; ?>
            <p class="submit"><button class="button button-primary button-hero" type="submit">حفظ التغييرات</button>
                <button class="button" type="submit" name="al_reset" value="1" onclick="return confirm('هل تريد إعادة كل محتوى هذه الصفحة للنصوص والصور الأصلية؟');">إعادة المحتوى الأصلي</button></p>
        </form>
    </div>
    <?php
}

add_action('admin_post_alenaya_save_content', function () {
    if (!current_user_can('manage_options') || !isset($_POST['al_admin_nonce']) || !wp_verify_nonce($_POST['al_admin_nonce'], 'alenaya_save_content')) { wp_die('Not allowed'); }
    $slug = sanitize_key($_POST['al_page']);
    $defs = al_defaults();
    if (!isset($defs['pages'][$slug])) { wp_die('Unknown page'); }
    $st = get_option('alenaya_content', array());
    if (!is_array($st)) { $st = array(); }
    $keys = array();
    foreach ($defs['pages'][$slug]['groups'] as $g) { $keys = array_merge($keys, $g[1]); }
    if (!empty($_POST['al_reset'])) {
        foreach ($keys as $k) { unset($st[$k]); }
        update_option('alenaya_content', $st);
        wp_safe_redirect(admin_url('admin.php?page=alenaya-' . $slug . '&reset=1')); exit;
    }
    $post = isset($_POST['al']) ? wp_unslash($_POST['al']) : array();
    foreach ($keys as $k) {
        if (!isset($defs['fields'][$k]) || !isset($post[$k])) { continue; }
        $type = $defs['fields'][$k]['type'];
        if ($type === 'image') {
            $url = isset($post[$k]['en']) ? esc_url_raw($post[$k]['en']) : '';
            if ($url === '') { unset($st[$k]); } else { $st[$k] = array('en' => $url); }
            continue;
        }
        $st[$k] = array(
            'en' => isset($post[$k]['en']) ? wp_kses($post[$k]['en'], al_allowed_html()) : '',
            'ar' => isset($post[$k]['ar']) ? wp_kses($post[$k]['ar'], al_allowed_html()) : '',
        );
    }
    update_option('alenaya_content', $st);
    wp_safe_redirect(admin_url('admin.php?page=alenaya-' . $slug . '&saved=1')); exit;
});

/* ------------------------------------------------------------- settings */
function al_settings_fields() {
    return array(
        'عام' => array(
            'default_lang' => array('اللغة الافتراضية للموقع', 'select', array('ar' => 'العربية (RTL)', 'en' => 'English (LTR)')),
            'show_lang_switch' => array('إظهار مبدّل اللغة EN / AR في الهيدر', 'select', array('1' => 'نعم', '0' => 'لا')),
            'home_services_limit' => array('عدد الخدمات المعروضة في كل تصنيف بالصفحة الرئيسية (0 = عرض الكل، مثال: 3 أو 4)', 'number'),
        ),
        'واتساب والتواصل' => array(
            'whatsapp_number' => array('رقم الواتساب (بصيغة دولية بدون + أو أصفار، مثال: 966501234567)', 'text'),
            'whatsapp_msg_en' => array('رسالة الواتساب الافتراضية (EN)', 'text'),
            'whatsapp_msg_ar' => array('رسالة الواتساب الافتراضية (AR)', 'text'),
            'email' => array('البريد الإلكتروني المعروض في الموقع', 'text'),
            'phone' => array('رقم الهاتف المعروض في الموقع', 'text'),
            'map_query' => array('عنوان/اسم الموقع على الخريطة (خرائط جوجل)', 'text'),
            'social_linkedin' => array('رابط لينكدإن', 'text'), 'social_instagram' => array('رابط إنستجرام', 'text'), 'social_x' => array('رابط X (تويتر)', 'text'),
        ),
        'نماذج الاتصال والبريد' => array(
            'form_to' => array('البريد الذي تصل إليه رسائل النماذج (يُترك فارغاً = بريد مدير الموقع)', 'text'),
            'form_cc' => array('نسخة إلى (CC) — عدة عناوين مفصولة بفاصلة', 'text'),
            'form_from_name' => array('اسم المرسل', 'text'),
            'form_from_email' => array('بريد المرسل (يُفضل بريد على نفس نطاق الموقع مثل no-reply@yourdomain.com)', 'text'),
        ),
        'SMTP مدمج (اختياري — بديل لإضافة WP Mail SMTP)' => array(
            'smtp_enable' => array('تفعيل SMTP المدمج', 'select', array('0' => 'لا (استخدم إضافة أو إرسال الاستضافة)', '1' => 'نعم')),
            'smtp_host' => array('خادم SMTP (مثال: smtp.gmail.com أو mail.yourdomain.com)', 'text'),
            'smtp_port' => array('المنفذ (587 مع TLS، 465 مع SSL)', 'text'),
            'smtp_secure' => array('التشفير', 'select', array('tls' => 'TLS', 'ssl' => 'SSL', '' => 'بدون')),
            'smtp_user' => array('اسم المستخدم (البريد الكامل)', 'text'),
            'smtp_pass' => array('كلمة المرور / App Password', 'password'),
        ),
    );
}

function al_page_settings() {
    $s = al_settings();
    ?>
    <div class="wrap al-wrap" dir="rtl">
        <h1>الإعدادات العامة</h1>
        <?php al_admin_notice(); ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="alenaya_save_settings">
            <?php wp_nonce_field('alenaya_save_settings', 'al_admin_nonce'); ?>
            <?php foreach (al_settings_fields() as $title => $fields) : ?>
                <details class="al-group" open><summary><?php echo esc_html($title); ?></summary>
                <?php foreach ($fields as $k => $f) : ?>
                    <div class="al-row"><div class="al-meta"><b><?php echo esc_html($f[0]); ?></b></div>
                    <?php if ($f[1] === 'select') : ?>
                        <select name="s[<?php echo esc_attr($k); ?>]"><?php foreach ($f[2] as $v => $l) { echo '<option value="' . esc_attr($v) . '"' . selected((string) $s[$k], (string) $v, false) . '>' . esc_html($l) . '</option>'; } ?></select>
                    <?php else : ?>
                        <input type="<?php echo esc_attr($f[1]); ?>" class="large-text" name="s[<?php echo esc_attr($k); ?>]" value="<?php echo esc_attr($s[$k]); ?>" dir="ltr" autocomplete="off">
                    <?php endif; ?></div>
                <?php endforeach; ?>
                </details>
            <?php endforeach; ?>
            <p class="submit"><button class="button button-primary button-hero" type="submit">حفظ الإعدادات</button>
            <button class="button" type="submit" name="al_test_mail" value="1">حفظ + إرسال رسالة اختبار</button></p>
        </form>
    </div>
    <?php
}

add_action('admin_post_alenaya_save_settings', function () {
    if (!current_user_can('manage_options') || !isset($_POST['al_admin_nonce']) || !wp_verify_nonce($_POST['al_admin_nonce'], 'alenaya_save_settings')) { wp_die('Not allowed'); }
    $in = isset($_POST['s']) ? wp_unslash($_POST['s']) : array();
    $clean = al_settings_defaults();
    foreach ($clean as $k => $v) {
        if (!isset($in[$k])) { continue; }
        if (strpos($k, 'social_') === 0) { $clean[$k] = esc_url_raw($in[$k]); }
        elseif (in_array($k, array('form_to', 'form_from_email', 'email'), true)) { $clean[$k] = sanitize_email($in[$k]); }
        elseif ($k === 'smtp_pass') { $clean[$k] = (string) $in[$k]; }
        else { $clean[$k] = sanitize_text_field($in[$k]); }
    }
    update_option('alenaya_settings', $clean);
    if (!empty($_POST['al_test_mail'])) {
        $to = is_email($clean['form_to']) ? $clean['form_to'] : get_option('admin_email');
        $GLOBALS['al_mail_error'] = '';
        add_filter('wp_mail_from_name', function () use ($clean) { return $clean['form_from_name']; });
        $ok = wp_mail($to, 'AL-ENAYA — رسالة اختبار', "هذه رسالة اختبار من إعدادات ثيم العناية.\nإذا وصلتك فإعدادات البريد تعمل بشكل صحيح.");
        set_transient('al_test_mail_result', $ok ? 'تم إرسال رسالة الاختبار إلى ' . $to : 'فشل الإرسال: ' . $GLOBALS['al_mail_error'], 60);
    }
    wp_safe_redirect(admin_url('admin.php?page=alenaya-settings&saved=1')); exit;
});

add_action('admin_notices', function () {
    $r = get_transient('al_test_mail_result');
    if ($r) { delete_transient('al_test_mail_result'); echo '<div class="notice notice-info"><p><b>نتيجة اختبار البريد:</b> ' . esc_html($r) . '</p></div>'; }
});

/* ------------------------------------------------------------- logos + client cards repeaters */
function al_repeater_row($name, $i, $fields, $row) {
    echo '<li class="al-rep-row"><span class="al-handle dashicons dashicons-move"></span><div class="al-rep-fields">';
    foreach ($fields as $k => $f) {
        $v = isset($row[$k]) ? $row[$k] : '';
        echo '<label class="al-rep-f"><span>' . esc_html($f[0]) . '</span>';
        if ($f[1] === 'image') {
            echo '<span class="al-rep-img"><img src="' . esc_url($v ? $v : AL_URI . '/assets/images/client-logo.png') . '" alt=""><input type="hidden" class="al-img-url" name="' . esc_attr($name) . '[' . $i . '][' . $k . ']" value="' . esc_attr($v) . '"><button type="button" class="button al-pick">اختيار صورة</button></span>';
        } elseif ($f[1] === 'select') {
            echo '<select name="' . esc_attr($name) . '[' . $i . '][' . $k . ']">';
            foreach ($f[2] as $ov => $ol) { echo '<option value="' . esc_attr($ov) . '"' . selected($v, $ov, false) . '>' . esc_html($ol) . '</option>'; }
            echo '</select>';
        } else {
            echo '<input type="text" name="' . esc_attr($name) . '[' . $i . '][' . $k . ']" value="' . esc_attr($v) . '"' . (substr($k, -3) === '_ar' ? ' dir="rtl"' : '') . '>';
        }
        echo '</label>';
    }
    echo '</div><button type="button" class="button-link-delete al-del">حذف</button></li>';
}

function al_repeater($name, $fields, $rows, $add_label, $multi_img = false) {
    echo '<div class="al-repeater" data-name="' . esc_attr($name) . '" data-multi="' . ($multi_img ? '1' : '0') . '"><ul class="al-rep-list">';
    foreach (array_values($rows) as $i => $row) { al_repeater_row($name, $i, $fields, $row); }
    echo '</ul>';
    echo '<script type="text/template" class="al-rep-tpl">';
    al_repeater_row($name, '__i__', $fields, array());
    echo '</script>';
    echo '<p><button type="button" class="button button-secondary al-add">' . esc_html($add_label) . '</button> ' . ($multi_img ? '<button type="button" class="button al-add-multi">إضافة عدة صور دفعة واحدة</button>' : '') . '</p></div>';
}

function al_page_logos() {
    $logo_fields = array('img' => array('الشعار', 'image'), 'name_en' => array('الاسم / النص البديل (EN)', 'text'), 'name_ar' => array('الاسم / النص البديل (AR)', 'text'));
    $card_fields = array(
        'sector' => array('القطاع (للفلترة)', 'select', array('religious' => 'ديني ومدني', 'residential' => 'قصور ومساكن', 'corporate' => 'شركات وصناعة', 'hospitality' => 'ضيافة')),
        'tag_en' => array('الوصف الصغير (EN)', 'text'), 'tag_ar' => array('الوصف الصغير (AR)', 'text'),
        'name_en' => array('اسم العميل (EN)', 'text'), 'name_ar' => array('اسم العميل (AR)', 'text'),
        'desc_en' => array('الموقع/التفاصيل (EN)', 'text'), 'desc_ar' => array('الموقع/التفاصيل (AR)', 'text'),
    );
    ?>
    <div class="wrap al-wrap" dir="rtl">
        <h1>شعارات وبطاقات العملاء</h1>
        <?php al_admin_notice(); ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="alenaya_save_logos">
            <?php wp_nonce_field('alenaya_save_logos', 'al_admin_nonce'); ?>
            <details class="al-group" open><summary>شريط شعارات العملاء (الصفحة الرئيسية) — اسحب لإعادة الترتيب</summary>
                <p class="al-lead">أضف أي عدد من الشعارات أو احذفها. يمكنك اختيار عدة صور دفعة واحدة من مكتبة الوسائط.</p>
                <?php al_repeater('logos', $logo_fields, al_logos(), '+ إضافة شعار', true); ?>
            </details>
            <details class="al-group" open><summary>بطاقات العملاء (صفحة العملاء)</summary>
                <?php al_repeater('cards', $card_fields, al_client_cards(), '+ إضافة عميل'); ?>
            </details>
            <p class="submit"><button class="button button-primary button-hero" type="submit">حفظ</button></p>
        </form>
    </div>
    <?php
}

add_action('admin_post_alenaya_save_logos', function () {
    if (!current_user_can('manage_options') || !isset($_POST['al_admin_nonce']) || !wp_verify_nonce($_POST['al_admin_nonce'], 'alenaya_save_logos')) { wp_die('Not allowed'); }
    $logos = array();
    if (!empty($_POST['logos']) && is_array($_POST['logos'])) {
        foreach (wp_unslash($_POST['logos']) as $r) {
            if (empty($r['img']) && empty($r['name_en'])) { continue; }
            $logos[] = array('img' => esc_url_raw(isset($r['img']) ? $r['img'] : ''), 'name_en' => sanitize_text_field(isset($r['name_en']) ? $r['name_en'] : ''), 'name_ar' => sanitize_text_field(isset($r['name_ar']) ? $r['name_ar'] : ''));
        }
    }
    update_option('alenaya_logos', $logos);
    $cards = array();
    if (!empty($_POST['cards']) && is_array($_POST['cards'])) {
        foreach (wp_unslash($_POST['cards']) as $r) {
            if (empty($r['name_en']) && empty($r['name_ar'])) { continue; }
            $row = array();
            foreach (array('sector', 'tag_en', 'tag_ar', 'name_en', 'name_ar', 'desc_en', 'desc_ar') as $k) { $row[$k] = sanitize_text_field(isset($r[$k]) ? $r[$k] : ''); }
            $cards[] = $row;
        }
    }
    update_option('alenaya_client_cards', $cards);
    wp_safe_redirect(admin_url('admin.php?page=alenaya-logos&saved=1')); exit;
});

/* ------------------------------------------------------------- guide */
function al_page_guide() {
    ?>
    <div class="wrap al-wrap" dir="rtl">
        <h1>دليل ربط البريد والإضافات</h1>
        <details class="al-group" open><summary>1) كيف تصل رسائل النموذج إلى بريدك؟</summary>
            <ol class="al-guide">
                <li>اذهب إلى <b>إعدادات العناية ← الإعدادات العامة ← نماذج الاتصال والبريد</b> واكتب البريد المستقبل في «البريد الذي تصل إليه رسائل النماذج».</li>
                <li>اكتب «بريد المرسل» على نفس نطاق موقعك (مثال: <code>no-reply@yourdomain.com</code>) لتفادي الـ Spam.</li>
                <li>كل رسالة تُحفظ أيضاً في <b>رسائل الاستفسارات</b> داخل لوحة التحكم، فلا تضيع أي رسالة حتى لو تعطل الإيميل.</li>
            </ol></details>
        <details class="al-group" open><summary>2) ضمان وصول الإيميلات للـ Inbox (SMTP)</summary>
            <p>استضافات كثيرة تمنع دالة البريد الافتراضية أو تُرسلها للـ Spam، لذلك اختر <b>إحدى</b> الطريقتين:</p>
            <ol class="al-guide">
                <li><b>الطريقة الأولى (مدمجة):</b> من «الإعدادات العامة ← SMTP المدمج» أدخل: الخادم، المنفذ 587/TLS (أو 465/SSL)، اسم المستخدم وكلمة المرور، ثم اضغط «حفظ + إرسال رسالة اختبار».</li>
                <li><b>الطريقة الثانية (إضافة):</b> ثبّت إضافة <b>WP Mail SMTP</b> واتبع المعالج؛ اختر «Other SMTP» أو Gmail/Google Workspace/Microsoft 365 وأدخل بيانات حساب البريد. (لا تفعّل الطريقتين معاً.)</li>
                <li>أضف سجلات <b>SPF</b> و<b>DKIM</b> و<b>DMARC</b> لنطاقك من لوحة DNS (توفرها شركة الاستضافة/مزود البريد) لزيادة موثوقية الوصول.</li>
            </ol></details>
        <details class="al-group" open><summary>3) الإضافات الموصى بها</summary>
            <ul class="al-guide">
                <li><b>WP Mail SMTP</b> — وصول الإيميلات للـ Inbox (اختيارية إذا استخدمت SMTP المدمج).</li>
                <li><b>LiteSpeed Cache</b> (إن كانت الاستضافة LiteSpeed) أو <b>WP Super Cache / W3 Total Cache</b> — الكاش. <u>مهم:</u> أضف الكوكي <code>al_lang</code> إلى «Vary Cookies / Do not cache cookies» حتى لا تختلط اللغتان.</li>
                <li><b>Wordfence Security</b> أو <b>Solid Security</b> — حماية وجدار ناري.</li>
                <li><b>UpdraftPlus</b> — نسخ احتياطي تلقائي.</li>
                <li><b>Smush / ShortPixel</b> — ضغط الصور (صور التصميم كبيرة الحجم).</li>
                <li><b>Yoast SEO</b> أو <b>Rank Math</b> — تحسين محركات البحث (اختيارية).</li>
            </ul></details>
        <details class="al-group" open><summary>4) تفعيل الثيم لأول مرة</summary>
            <ol class="al-guide">
                <li>المظهر ← الثيمات ← إضافة ← رفع ثيم ← اختر <code>alenaya-theme.zip</code> ← تفعيل.</li>
                <li>عند التفعيل ينشئ الثيم الصفحات والخدمات والمشاريع والمحتوى الأصلي تلقائياً ويضبط الصفحة الرئيسية وروابط الموقع.</li>
                <li>اذهب إلى الإعدادات ← الدوائم ← اضغط حفظ مرة واحدة.</li>
            </ol></details>
    </div>
    <?php
}
