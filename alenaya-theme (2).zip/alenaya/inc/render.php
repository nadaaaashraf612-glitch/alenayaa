<?php
/**
 * Dynamic section renderers (services, clients, projects...).
 */
if (!defined('ABSPATH')) { exit; }

function al_query_services($cat_id = 0, $limit = -1, $home_only = false) {
    $args = array('post_type' => 'service', 'post_status' => 'publish', 'posts_per_page' => $limit, 'orderby' => 'menu_order title', 'order' => 'ASC', 'no_found_rows' => true);
    if ($cat_id) { $args['tax_query'] = array(array('taxonomy' => 'service_category', 'field' => 'term_id', 'terms' => $cat_id)); }
    if ($home_only) {
        $args['meta_query'] = array('relation' => 'OR', array('key' => 'al_hide_home', 'compare' => 'NOT EXISTS'), array('key' => 'al_hide_home', 'value' => '1', 'compare' => '!='));
    }
    return get_posts($args);
}

/** Services tabs + panels (home: limited & card is article / archive: all services & card is link) */
function al_render_services_tabs($args = array()) {
    $mode = isset($args['mode']) ? $args['mode'] : 'home';
    $limit = ($mode === 'home') ? (int) al_opt('home_services_limit') : 0;
    if ($limit <= 0) { $limit = -1; }
    $cats = al_terms_sorted('service_category', true);
    $tabs = array();
    foreach ($cats as $cat) {
        $posts = al_query_services($cat->term_id, $limit, $mode === 'home');
        if ($posts) { $tabs[] = array($cat, $posts); }
    }
    if (!$tabs) {
        echo '<p class="al-empty" style="padding:30px 0;text-align:center">—</p>';
        return;
    }
    echo '<div class="service-tablist" role="tablist" aria-label="Service categories">';
    foreach ($tabs as $i => $t) {
        $slug = $t[0]->slug;
        echo '<button class="service-tab' . ($i === 0 ? ' active' : '') . '" type="button" role="tab" id="tab-' . esc_attr($slug) . '" aria-controls="panel-' . esc_attr($slug) . '" aria-selected="' . ($i === 0 ? 'true' : 'false') . '" data-service-tab="' . esc_attr($slug) . '">' . esc_html(al_term_field($t[0], 'name')) . '</button>';
    }
    echo '</div><div class="service-panels">';
    foreach ($tabs as $i => $t) {
        $slug = $t[0]->slug;
        echo '<div class="service-panel' . ($i === 0 ? ' active' : '') . '" id="panel-' . esc_attr($slug) . '" role="tabpanel" aria-labelledby="tab-' . esc_attr($slug) . '" data-service-panel="' . esc_attr($slug) . '"' . ($i === 0 ? '' : ' hidden') . '>';
        foreach ($t[1] as $p) { al_service_card($p, $mode); }
        echo '</div>';
    }
    echo '</div>';
}

function al_service_card($p, $mode) {
    $title = al_post_field($p->ID, 'title');
    $exc = al_post_field($p->ID, 'excerpt');
    $img = al_post_image_url($p->ID, 'large');
    $url = get_permalink($p);
    if ($mode === 'archive') {
        echo '<a class="service-photo-card" href="' . esc_url($url) . '"><div class="service-card-media" style="--img:url(' . esc_url($img) . ')" role="img" aria-label="' . esc_attr($title) . '"></div><div class="service-card-body"><h3>' . esc_html($title) . '</h3><p>' . esc_html($exc) . '</p></div></a>';
        return;
    }
    echo '<article class="service-photo-card" data-href="' . esc_url($url) . '" tabindex="0" role="link" aria-label="' . esc_attr($title) . '"><div class="service-card-media" style="--img:url(' . esc_url($img) . ')" role="img" aria-label="' . esc_attr($title) . '"></div><div class="service-card-body"><div><h3>' . esc_html($title) . '</h3><p>' . esc_html($exc) . '</p></div></div></article>';
}

/* ---------------------------------------------------------------- clients logos (home marquee) */
function al_logos() {
    $logos = get_option('alenaya_logos', null);
    if (!is_array($logos)) {
        $seed = al_seed_data();
        $logos = array();
        for ($i = 0; $i < 4; $i++) {
            $logos[] = array('img' => '', 'name_en' => $i === 0 ? $seed['logo_alt'] : '', 'name_ar' => $i === 0 ? $seed['logo_alt_ar'] : '');
        }
    }
    return $logos;
}

function al_render_client_marquee() {
    $logos = al_logos();
    if (!$logos) { return; }
    $items = $logos;
    while (count($items) < 4) { $items = array_merge($items, $logos); }
    $ar = al_lang() === 'ar';
    foreach (array(false, true) as $dup) {
        foreach ($items as $i => $l) {
            $src = !empty($l['img']) ? $l['img'] : AL_URI . '/assets/images/client-logo.png';
            $alt = $ar && !empty($l['name_ar']) ? $l['name_ar'] : (isset($l['name_en']) ? $l['name_en'] : '');
            if ($dup) {
                echo '<div class="client-marquee-item" aria-hidden="true"><img src="' . esc_url($src) . '" alt="" loading="lazy"></div>';
            } else {
                echo '<div class="client-marquee-item"><img src="' . esc_url($src) . '" alt="' . esc_attr($alt) . '" loading="lazy"></div>';
            }
        }
    }
}

/* ---------------------------------------------------------------- client cards (clients page) */
function al_client_cards() {
    $cards = get_option('alenaya_client_cards', null);
    if (!is_array($cards)) {
        $seed = al_seed_data();
        $cards = array();
        foreach ($seed['client_cards'] as $c) {
            $cards[] = array('sector' => $c['sector'], 'tag_en' => $c['tag'], 'tag_ar' => $c['tag_ar'], 'name_en' => $c['name'], 'name_ar' => $c['name_ar'], 'desc_en' => $c['desc'], 'desc_ar' => $c['desc_ar']);
        }
    }
    return $cards;
}

function al_render_client_cards() {
    $ar = al_lang() === 'ar';
    foreach (al_client_cards() as $c) {
        $pick = function ($k) use ($c, $ar) { return ($ar && !empty($c[$k . '_ar'])) ? $c[$k . '_ar'] : (isset($c[$k . '_en']) ? $c[$k . '_en'] : ''); };
        echo '<article class="client-card" data-sector="' . esc_attr($c['sector']) . '"><span class="client-sector">' . esc_html($pick('tag')) . '</span><h3>' . esc_html($pick('name')) . '</h3><p>' . esc_html($pick('desc')) . '</p></article>';
    }
}

/* ---------------------------------------------------------------- project categories (projects page) */
function al_project_cat_image($term) {
    $img = get_term_meta($term->term_id, 'al_image', true);
    if ($img) { return $img; }
    $cell = get_term_meta($term->term_id, 'al_cell', true);
    if ($cell && strpos($cell, ',') !== false) { $p = array_map('intval', explode(',', $cell)); return al_cell_url($p[0], $p[1]); }
    return al_cell_url(0, 0);
}

function al_count_label($n) {
    return $n . ' ' . ($n === 1 ? al_tr('single.cat.project') : al_tr('single.cat.projects'));
}

function al_render_project_categories() {
    foreach (al_terms_sorted('project_category', false) as $t) {
        echo '<a class="category-card" href="' . esc_url(get_term_link($t)) . '" style="--img:url(' . esc_url(al_project_cat_image($t)) . ')"><h3>' . esc_html(al_term_field($t, 'name')) . '</h3><p>' . esc_html(al_term_field($t, 'desc')) . '</p><div class="category-foot"><span>' . esc_html(al_count_label((int) $t->count)) . '</span><span>→</span></div></a>';
    }
}

/* ---------------------------------------------------------------- contact form helpers */
function al_form_hidden_fields() {
    echo '<input type="hidden" name="action" value="alenaya_contact">';
    wp_nonce_field('alenaya_contact', 'al_nonce');
    echo '<input type="text" name="al_website" value="" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px;opacity:0" aria-hidden="true">';
    echo '<input type="hidden" name="al_lang" value="' . esc_attr(al_lang()) . '">';
    echo '<input type="hidden" name="al_redirect" value="' . esc_url(get_permalink()) . '">';
}

/* ---------------------------------------------------------------- site search */
add_action('pre_get_posts', function ($q) {
    if (!is_admin() && $q->is_main_query() && $q->is_search()) {
        $q->set('post_type', array('service', 'project', 'page'));
        $q->set('posts_per_page', 20);
    }
});

/** IDs of services/projects whose Arabic meta fields match the search text */
function al_search_extra_ids($term) {
    global $wpdb;
    $like = '%' . $wpdb->esc_like($term) . '%';
    $ids = $wpdb->get_col($wpdb->prepare("SELECT DISTINCT pm.post_id FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.post_status = 'publish' AND p.post_type IN ('service','project') AND pm.meta_key IN ('al_title_ar','al_excerpt_ar','al_desc_ar','al_location','al_location_ar') AND pm.meta_value LIKE %s", $like));
    return array_map('intval', $ids ? $ids : array());
}

function al_search_index_items() {
    $items = array();
    foreach (al_query_services(0, 60) as $p) {
        $terms = wp_get_post_terms($p->ID, 'service_category', array('fields' => 'names'));
        $hay = strtolower(implode(' ', array($p->post_title, get_post_meta($p->ID, 'al_title_ar', true), $p->post_excerpt, get_post_meta($p->ID, 'al_excerpt_ar', true), is_array($terms) ? implode(' ', $terms) : '')));
        $items[] = array('title' => al_post_field($p->ID, 'title'), 'url' => get_permalink($p), 'hay' => $hay);
    }
    return $items;
}
