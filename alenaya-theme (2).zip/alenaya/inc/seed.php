<?php
/**
 * Seeds the original content on theme activation (pages, services, projects, categories).
 */
if (!defined('ABSPATH')) { exit; }

function al_seed_data() {
    static $d = null;
    if ($d === null) { $d = require AL_DIR . '/inc/seed-data.php'; }
    return $d;
}

add_action('after_switch_theme', function () {
    al_seed(false);
    flush_rewrite_rules();
});

add_action('admin_init', function () {
    if (!get_option('alenaya_seeded') && current_user_can('manage_options') && get_option('stylesheet') === 'alenaya') {
        al_seed(false);
        flush_rewrite_rules();
    }
});

function al_seed($force = false) {
    if (!$force && get_option('alenaya_seeded')) { return; }
    $d = al_seed_data();

    // ---- pages
    $pages = array(
        'home' => array('Home — الرئيسية', 'front-page.php'),
        'about' => array('About — من نحن', 'page-about.php'),
        'services' => array('Services — الخدمات', 'page-services.php'),
        'projects' => array('Projects — المشاريع', 'page-projects.php'),
        'clients' => array('Clients — العملاء', 'page-clients.php'),
        'certifications' => array('Certifications — الشهادات', 'page-certifications.php'),
        'contact' => array('Contact — اتصل بنا', 'page-contact.php'),
        'faq' => array('FAQ — الأسئلة الشائعة', 'page-faq.php'),
        'privacy' => array('Privacy Policy — سياسة الخصوصية', 'page-privacy.php'),
    );
    $ids = array();
    foreach ($pages as $slug => $p) {
        $existing = get_page_by_path($slug);
        if ($existing) { $id = $existing->ID; }
        else { $id = wp_insert_post(array('post_type' => 'page', 'post_status' => 'publish', 'post_title' => $p[0], 'post_name' => $slug, 'post_content' => '')); }
        if ($id && !is_wp_error($id)) {
            update_post_meta($id, '_wp_page_template', $p[1]);
            $ids[$slug] = $id;
        }
    }
    update_option('alenaya_pages', $ids);
    if (!empty($ids['home'])) { update_option('show_on_front', 'page'); update_option('page_on_front', $ids['home']); }
    if (!get_option('permalink_structure')) { update_option('permalink_structure', '/%postname%/'); }

    // ---- service categories + services
    $cat_ids = array();
    foreach ($d['service_cats'] as $c) {
        $t = term_exists($c['slug'], 'service_category');
        if (!$t) { $t = wp_insert_term($c['en'], 'service_category', array('slug' => $c['slug'])); }
        if (is_wp_error($t)) { continue; }
        $tid = is_array($t) ? (int) $t['term_id'] : (int) $t;
        $cat_ids[$c['slug']] = $tid;
        update_term_meta($tid, 'al_name_ar', $c['ar']);
        update_term_meta($tid, 'al_order', $c['order']);
    }
    foreach ($d['services'] as $s) {
        if (get_page_by_path($s['slug'], OBJECT, 'service')) { continue; }
        $id = wp_insert_post(array('post_type' => 'service', 'post_status' => 'publish', 'post_title' => $s['title'], 'post_name' => $s['slug'], 'post_excerpt' => $s['excerpt'], 'post_content' => $s['desc'], 'menu_order' => $s['order']));
        if (!$id || is_wp_error($id)) { continue; }
        update_post_meta($id, 'al_title_ar', $s['title_ar']);
        update_post_meta($id, 'al_excerpt_ar', $s['excerpt_ar']);
        update_post_meta($id, 'al_desc_ar', $s['desc_ar']);
        update_post_meta($id, 'al_steps', implode("\n", $s['steps']));
        update_post_meta($id, 'al_steps_ar', implode("\n", $s['steps_ar']));
        update_post_meta($id, 'al_cell', $s['cell'][0] . ',' . $s['cell'][1]);
        if (isset($cat_ids[$s['cat']])) { wp_set_object_terms($id, array((int) $cat_ids[$s['cat']]), 'service_category'); }
    }

    // ---- project categories + projects
    $pcat = array();
    foreach ($d['project_cats'] as $c) {
        $t = term_exists($c['slug'], 'project_category');
        if (!$t) { $t = wp_insert_term($c['title'], 'project_category', array('slug' => $c['slug'], 'description' => $c['desc'])); }
        if (is_wp_error($t)) { continue; }
        $tid = is_array($t) ? (int) $t['term_id'] : (int) $t;
        $pcat[$c['slug']] = $tid;
        update_term_meta($tid, 'al_name_ar', $c['title_ar']);
        update_term_meta($tid, 'al_desc_ar', $c['desc_ar']);
        update_term_meta($tid, 'al_order', $c['order']);
        update_term_meta($tid, 'al_page_title', $c['page_title']);
        update_term_meta($tid, 'al_page_title_ar', $c['page_title_ar']);
        update_term_meta($tid, 'al_page_desc', $c['page_desc']);
        update_term_meta($tid, 'al_page_desc_ar', $c['page_desc_ar']);
        update_term_meta($tid, 'al_cell', $c['cell'][0] . ',' . $c['cell'][1]);
    }
    foreach ($d['projects'] as $i => $p) {
        $slug = sanitize_title($p['title']);
        if (get_page_by_path($slug, OBJECT, 'project')) { continue; }
        $id = wp_insert_post(array('post_type' => 'project', 'post_status' => 'publish', 'post_title' => $p['title'], 'post_name' => $slug, 'post_excerpt' => $p['desc'], 'menu_order' => $p['order']));
        if (!$id || is_wp_error($id)) { continue; }
        update_post_meta($id, 'al_title_ar', $p['title_ar']);
        update_post_meta($id, 'al_excerpt_ar', $p['desc_ar']);
        update_post_meta($id, 'al_location', $p['loc']);
        update_post_meta($id, 'al_location_ar', $p['loc_ar']);
        update_post_meta($id, 'al_cell', $p['cell'][0] . ',' . $p['cell'][1]);
        if (isset($pcat[$p['cat']])) { wp_set_object_terms($id, array((int) $pcat[$p['cat']]), 'project_category'); }
    }
    update_option('alenaya_seeded', 1);
}
