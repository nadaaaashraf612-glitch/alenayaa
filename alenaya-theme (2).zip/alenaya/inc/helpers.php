<?php
/**
 * Core helpers: language, content store, URLs, images.
 */
if (!defined('ABSPATH')) { exit; }

/* ------------------------------------------------------------------ settings */
function al_settings_defaults() {
    return array(
        'default_lang'     => 'ar',
        'show_lang_switch' => '1',
        'whatsapp_number'  => '966500000000',
        'whatsapp_msg_en'  => 'Hello AL-ENAYA, I would like to request a service.',
        'whatsapp_msg_ar'  => 'مرحباً العناية، أرغب في طلب خدمة.',
        'email'            => 'info@al-enaya.sa',
        'phone'            => '+966 11 000 0000',
        'map_query'        => 'Kingdom of Saudi Arabia',
        'home_services_limit' => '0',
        'form_to'          => '',
        'form_cc'          => '',
        'form_from_name'   => 'AL-ENAYA Website',
        'form_from_email'  => '',
        'smtp_enable'      => '0',
        'smtp_host'        => '',
        'smtp_port'        => '587',
        'smtp_secure'      => 'tls',
        'smtp_user'        => '',
        'smtp_pass'        => '',
        'social_linkedin'  => '#',
        'social_instagram' => '#',
        'social_x'         => '#',
    );
}

function al_settings() {
    static $s = null;
    if ($s === null) {
        $saved = get_option('alenaya_settings', array());
        $s = array_merge(al_settings_defaults(), is_array($saved) ? $saved : array());
    }
    return $s;
}

function al_reset_settings_cache() {
    // settings are read once per request; nothing else to clear.
}

function al_opt($key) {
    $s = al_settings();
    if ($key === 'phone_tel') {
        return preg_replace('/[^0-9+]/', '', $s['phone']);
    }
    return isset($s[$key]) ? $s[$key] : '';
}

/* ------------------------------------------------------------------ language */
function al_lang() {
    static $lang = null;
    if ($lang !== null) { return $lang; }
    $allowed = array('ar', 'en');
    $lang = al_opt('default_lang');
    if (!in_array($lang, $allowed, true)) { $lang = 'ar'; }
    if (isset($_COOKIE['al_lang']) && in_array($_COOKIE['al_lang'], $allowed, true)) {
        $lang = $_COOKIE['al_lang'];
    }
    if (isset($_GET['lang']) && in_array($_GET['lang'], $allowed, true)) {
        $lang = $_GET['lang'];
        if (!headers_sent()) {
            setcookie('al_lang', $lang, time() + 60 * 60 * 24 * 365, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN);
        }
    }
    return $lang;
}

function al_is_rtl() { return al_lang() === 'ar'; }

function al_lang_attr() { return al_lang() === 'ar' ? 'ar' : 'en'; }

/* ------------------------------------------------------------------ content store */
function al_defaults() {
    static $d = null;
    if ($d === null) { $d = require AL_DIR . '/inc/defaults.php'; }
    return $d;
}

function al_store() {
    static $st = null;
    if ($st === null) {
        $st = get_option('alenaya_content', array());
        if (!is_array($st)) { $st = array(); }
    }
    return $st;
}

function al_store_reset() {
    // used after saving in the same request (admin)
}

/** Returns the raw translated value of a content key. */
function al_t($key, $lang = null) {
    if ($lang === null) { $lang = al_lang(); }
    $d = al_defaults();
    $st = al_store();
    $def = isset($d['fields'][$key]) ? $d['fields'][$key] : array('en' => '', 'ar' => '');
    $en = (isset($st[$key]) && isset($st[$key]['en'])) ? $st[$key]['en'] : $def['en'];
    if ($lang === 'en') { return $en; }
    if (isset($st[$key]) && isset($st[$key]['ar']) && $st[$key]['ar'] !== '') { return $st[$key]['ar']; }
    if (!isset($st[$key]) && $def['ar'] !== '') { return $def['ar']; }
    return $en;
}

function al_e($key) {
    echo wp_kses(al_t($key), al_allowed_html());
}

function al_a($key) {
    echo esc_attr(wp_strip_all_tags(al_t($key)));
}

function al_allowed_html() {
    return array('br' => array(), 'strong' => array(), 'b' => array(), 'em' => array(), 'i' => array(),
        'span' => array('class' => array()), 'a' => array('href' => array(), 'target' => array(), 'rel' => array()));
}

/** Replace {t} / {p} tokens. */
function al_tr($key, $repl = array()) {
    $s = wp_strip_all_tags(al_t($key), true);
    foreach ($repl as $k => $v) { $s = str_replace('{' . $k . '}', $v, $s); }
    return $s;
}

/** Image field: stored URL or bundled default. */
function al_img($key) {
    $st = al_store();
    if (!empty($st[$key]['en'])) { return $st[$key]['en']; }
    $d = al_defaults();
    $def = isset($d['fields'][$key]) ? $d['fields'][$key]['en'] : '';
    return AL_URI . '/assets/' . $def;
}

/* ------------------------------------------------------------------ urls */
function al_page_slugs() {
    return array('about', 'services', 'projects', 'clients', 'certifications', 'contact', 'faq', 'privacy');
}

function al_url($slug) {
    if ($slug === 'home') { return home_url('/'); }
    $ids = get_option('alenaya_pages', array());
    if (is_array($ids) && !empty($ids[$slug]) && get_post_status($ids[$slug]) === 'publish') {
        return get_permalink($ids[$slug]);
    }
    $p = get_page_by_path($slug);
    if ($p) { return get_permalink($p); }
    return home_url('/' . $slug . '/');
}

function al_service_url($slug) {
    $p = get_page_by_path($slug, OBJECT, 'service');
    if ($p) { return get_permalink($p); }
    return al_url('services');
}

function al_whatsapp_url() {
    $num = preg_replace('/\D+/', '', al_opt('whatsapp_number'));
    $msg = al_lang() === 'ar' ? al_opt('whatsapp_msg_ar') : al_opt('whatsapp_msg_en');
    $url = 'https://api.whatsapp.com/send?';
    if ($num) { $url .= 'phone=' . $num . '&'; }
    return $url . 'text=' . rawurlencode($msg);
}

function al_map_embed_url($q = '') {
    if ($q === '') { $q = al_opt('map_query'); }
    return 'https://www.google.com/maps?q=' . rawurlencode($q) . '&output=embed';
}

function al_map_link($q = '') {
    if ($q === '') { $q = al_opt('map_query'); }
    return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($q);
}

/* ------------------------------------------------------------------ header variant */
function al_set_header_variant($v) { $GLOBALS['al_header_variant'] = $v; }
function al_header_variant() { return isset($GLOBALS['al_header_variant']) ? $GLOBALS['al_header_variant'] : 'internal'; }

/* ------------------------------------------------------------------ post/term fields (bilingual) */
function al_post_field($post_id, $field) {
    $post = get_post($post_id);
    if (!$post) { return ''; }
    $ar = al_lang() === 'ar';
    switch ($field) {
        case 'title':
            $v = $ar ? get_post_meta($post_id, 'al_title_ar', true) : '';
            return $v !== '' && $v !== false ? $v : $post->post_title;
        case 'excerpt':
            $v = $ar ? get_post_meta($post_id, 'al_excerpt_ar', true) : '';
            return $v !== '' && $v !== false ? $v : $post->post_excerpt;
        case 'desc':
            $v = $ar ? get_post_meta($post_id, 'al_desc_ar', true) : '';
            return $v !== '' && $v !== false ? $v : $post->post_content;
        case 'location':
            $v = $ar ? get_post_meta($post_id, 'al_location_ar', true) : '';
            return $v !== '' && $v !== false ? $v : get_post_meta($post_id, 'al_location', true);
        case 'steps':
            $v = $ar ? get_post_meta($post_id, 'al_steps_ar', true) : '';
            if ($v === '' || $v === false) { $v = get_post_meta($post_id, 'al_steps', true); }
            return array_values(array_filter(array_map('trim', preg_split('/\r?\n/', (string) $v))));
    }
    return '';
}

function al_term_field($term, $field) {
    $ar = al_lang() === 'ar';
    $id = $term->term_id;
    switch ($field) {
        case 'name':
            $v = $ar ? get_term_meta($id, 'al_name_ar', true) : '';
            return $v ? $v : $term->name;
        case 'desc':
            $v = $ar ? get_term_meta($id, 'al_desc_ar', true) : '';
            return $v ? $v : $term->description;
        case 'page_title':
            $v = $ar ? get_term_meta($id, 'al_page_title_ar', true) : get_term_meta($id, 'al_page_title', true);
            if (!$v) { $v = get_term_meta($id, 'al_page_title', true); }
            return $v ? $v : $term->name;
        case 'page_desc':
            $v = $ar ? get_term_meta($id, 'al_page_desc_ar', true) : get_term_meta($id, 'al_page_desc', true);
            if (!$v) { $v = get_term_meta($id, 'al_page_desc', true); }
            return $v ? $v : $term->description;
    }
    return '';
}

function al_terms_sorted($taxonomy, $hide_empty = true) {
    $terms = get_terms(array('taxonomy' => $taxonomy, 'hide_empty' => $hide_empty));
    if (is_wp_error($terms) || !$terms) { return array(); }
    usort($terms, function ($a, $b) {
        $oa = (int) get_term_meta($a->term_id, 'al_order', true);
        $ob = (int) get_term_meta($b->term_id, 'al_order', true);
        if ($oa === $ob) { return $a->term_id - $b->term_id; }
        return $oa - $ob;
    });
    return $terms;
}

/** Default crop of the original sprite sheet: services/cell-rXcY.jpg */
function al_cell_url($r, $c) {
    return AL_URI . '/assets/images/services/cell-r' . (int) $r . 'c' . (int) $c . '.jpg';
}

function al_default_cells() {
    $cells = array();
    for ($r = 0; $r < 4; $r++) { for ($c = 0; $c < 4; $c++) { if ($r === 3 && $c === 3) { continue; } $cells[] = array($r, $c); } }
    return $cells;
}

function al_post_image_url($post_id, $size = 'large') {
    $u = get_the_post_thumbnail_url($post_id, $size);
    if ($u) { return $u; }
    $cell = get_post_meta($post_id, 'al_cell', true);
    if ($cell && strpos($cell, ',') !== false) {
        $p = array_map('intval', explode(',', $cell));
        return al_cell_url($p[0], $p[1]);
    }
    return al_cell_url(0, 0);
}

function al_cell_index($post_id) {
    $cell = get_post_meta($post_id, 'al_cell', true);
    $cells = al_default_cells();
    if ($cell && strpos($cell, ',') !== false) {
        $p = array_map('intval', explode(',', $cell));
        foreach ($cells as $i => $c) { if ($c[0] === $p[0] && $c[1] === $p[1]) { return $i; } }
    }
    return 0;
}

/** Gallery of a post: attachment IDs (comma separated) or 5 default crops. */
function al_gallery_urls($post_id, $offset = 0, $count = 5) {
    $ids = get_post_meta($post_id, 'al_gallery', true);
    $urls = array();
    if ($ids) {
        foreach (array_filter(array_map('intval', explode(',', $ids))) as $id) {
            $u = wp_get_attachment_image_url($id, 'large');
            if ($u) { $urls[] = $u; }
        }
    }
    if ($urls) { return $urls; }
    $cells = al_default_cells();
    $start = al_cell_index($post_id) + $offset;
    for ($i = 0; $i < $count; $i++) {
        $c = $cells[($start + $i) % count($cells)];
        $urls[] = al_cell_url($c[0], $c[1]);
    }
    return $urls;
}

function al_pin_svg() {
    return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s7-5 7-12a7 7 0 1 0-14 0c0 7 7 12 7 12Z"/><circle cx="12" cy="9" r="2"/></svg>';
}
