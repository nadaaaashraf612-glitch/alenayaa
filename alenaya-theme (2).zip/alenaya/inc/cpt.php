<?php
/**
 * Custom post types, taxonomies and meta boxes.
 */
if (!defined('ABSPATH')) { exit; }

add_action('init', 'al_register_types');
function al_register_types() {
    register_post_type('service', array(
        'labels' => array(
            'name' => 'الخدمات', 'singular_name' => 'خدمة', 'add_new' => 'إضافة خدمة', 'add_new_item' => 'إضافة خدمة جديدة',
            'edit_item' => 'تعديل الخدمة', 'new_item' => 'خدمة جديدة', 'view_item' => 'عرض الخدمة', 'search_items' => 'بحث في الخدمات',
            'not_found' => 'لا توجد خدمات', 'all_items' => 'كل الخدمات', 'menu_name' => 'الخدمات',
        ),
        'public' => true, 'has_archive' => false, 'show_in_rest' => true, 'menu_position' => 21, 'menu_icon' => 'dashicons-hammer',
        'supports' => array('title', 'editor', 'excerpt', 'thumbnail', 'page-attributes'),
        'rewrite' => array('slug' => 'service', 'with_front' => false),
    ));
    register_taxonomy('service_category', 'service', array(
        'labels' => array('name' => 'تصنيفات الخدمات', 'singular_name' => 'تصنيف خدمة', 'add_new_item' => 'إضافة تصنيف', 'edit_item' => 'تعديل التصنيف', 'menu_name' => 'تصنيفات الخدمات', 'search_items' => 'بحث في التصنيفات'),
        'hierarchical' => true, 'public' => true, 'show_admin_column' => true, 'show_in_rest' => true,
        'rewrite' => array('slug' => 'service-category', 'with_front' => false),
    ));
    register_post_type('project', array(
        'labels' => array(
            'name' => 'المشاريع', 'singular_name' => 'مشروع', 'add_new' => 'إضافة مشروع', 'add_new_item' => 'إضافة مشروع جديد',
            'edit_item' => 'تعديل المشروع', 'new_item' => 'مشروع جديد', 'view_item' => 'عرض المشروع', 'search_items' => 'بحث في المشاريع',
            'not_found' => 'لا توجد مشاريع', 'all_items' => 'كل المشاريع', 'menu_name' => 'المشاريع',
        ),
        'public' => true, 'has_archive' => false, 'show_in_rest' => true, 'menu_position' => 22, 'menu_icon' => 'dashicons-portfolio',
        'supports' => array('title', 'excerpt', 'thumbnail', 'page-attributes'),
        'rewrite' => array('slug' => 'project', 'with_front' => false),
    ));
    register_taxonomy('project_category', 'project', array(
        'labels' => array('name' => 'تصنيفات المشاريع', 'singular_name' => 'تصنيف مشروع', 'add_new_item' => 'إضافة تصنيف', 'edit_item' => 'تعديل التصنيف', 'menu_name' => 'تصنيفات المشاريع', 'search_items' => 'بحث في التصنيفات'),
        'hierarchical' => true, 'public' => true, 'show_admin_column' => true, 'show_in_rest' => true,
        'rewrite' => array('slug' => 'project-category', 'with_front' => false),
    ));
    register_post_type('al_enquiry', array(
        'labels' => array('name' => 'رسائل الاستفسارات', 'singular_name' => 'استفسار', 'menu_name' => 'رسائل الاستفسارات', 'all_items' => 'كل الرسائل', 'search_items' => 'بحث في الرسائل', 'not_found' => 'لا توجد رسائل', 'edit_item' => 'عرض الرسالة'),
        'public' => false, 'show_ui' => true, 'menu_position' => 23, 'menu_icon' => 'dashicons-email-alt',
        'supports' => array('title'), 'capabilities' => array('create_posts' => 'do_not_allow'), 'map_meta_cap' => true,
    ));
}

/* --------------------------------------------------------- ordering in admin lists */
add_action('pre_get_posts', function ($q) {
    if (is_admin() && $q->is_main_query() && in_array($q->get('post_type'), array('service', 'project'), true) && !$q->get('orderby')) {
        $q->set('orderby', 'menu_order title');
        $q->set('order', 'ASC');
    }
});

/* --------------------------------------------------------- term meta forms */
function al_term_fields($tax) {
    $f = array(
        'al_name_ar' => 'الاسم بالعربية', 'al_desc_ar' => 'الوصف بالعربية', 'al_order' => 'الترتيب (رقم أصغر = يظهر أولاً)',
    );
    if ($tax === 'project_category') {
        $f['al_page_title'] = 'عنوان صفحة التصنيف (EN)';
        $f['al_page_title_ar'] = 'عنوان صفحة التصنيف (AR)';
        $f['al_page_desc'] = 'وصف صفحة التصنيف (EN)';
        $f['al_page_desc_ar'] = 'وصف صفحة التصنيف (AR)';
        $f['al_image'] = 'صورة بطاقة التصنيف (رابط الصورة من مكتبة الوسائط)';
    }
    return $f;
}

foreach (array('service_category', 'project_category') as $al_tax) {
    add_action($al_tax . '_add_form_fields', function ($tax) {
        foreach (al_term_fields($tax) as $k => $label) {
            echo '<div class="form-field"><label for="' . esc_attr($k) . '">' . esc_html($label) . '</label>';
            if (strpos($k, 'desc') !== false) { echo '<textarea name="' . esc_attr($k) . '" id="' . esc_attr($k) . '" rows="3"></textarea>'; }
            else { echo '<input type="text" name="' . esc_attr($k) . '" id="' . esc_attr($k) . '" ' . ($k === 'al_order' ? 'value="0"' : '') . '>'; }
            echo '</div>';
        }
    });
    add_action($al_tax . '_edit_form_fields', function ($term, $tax) {
        foreach (al_term_fields($tax) as $k => $label) {
            $v = get_term_meta($term->term_id, $k, true);
            echo '<tr class="form-field"><th scope="row"><label for="' . esc_attr($k) . '">' . esc_html($label) . '</label></th><td>';
            if (strpos($k, 'desc') !== false) { echo '<textarea name="' . esc_attr($k) . '" id="' . esc_attr($k) . '" rows="3" class="large-text">' . esc_textarea($v) . '</textarea>'; }
            else { echo '<input type="text" class="regular-text" name="' . esc_attr($k) . '" id="' . esc_attr($k) . '" value="' . esc_attr($v) . '">'; }
            echo '</td></tr>';
        }
    }, 10, 2);
    $save = function ($term_id, $tt_id = 0, $taxonomy = '') {
        $tax = $taxonomy ? $taxonomy : (isset($_POST['taxonomy']) ? sanitize_key($_POST['taxonomy']) : '');
        if (!in_array($tax, array('service_category', 'project_category'), true)) { return; }
        if (!current_user_can('manage_categories')) { return; }
        foreach (al_term_fields($tax) as $k => $label) {
            if (isset($_POST[$k])) {
                $v = wp_unslash($_POST[$k]);
                $v = $k === 'al_image' ? esc_url_raw($v) : ($k === 'al_order' ? (int) $v : sanitize_textarea_field($v));
                update_term_meta($term_id, $k, $v);
            }
        }
    };
    add_action('created_' . $al_tax, $save, 10, 3);
    add_action('edited_' . $al_tax, $save, 10, 3);
}

/* --------------------------------------------------------- meta boxes */
add_action('add_meta_boxes', function () {
    add_meta_box('al_service_box', 'تفاصيل الخدمة (عربي / خطوات / إعدادات)', 'al_service_box', 'service', 'normal', 'high');
    add_meta_box('al_project_box', 'تفاصيل المشروع (عربي / الموقع)', 'al_project_box', 'project', 'normal', 'high');
    add_meta_box('al_gallery_box', 'معرض الصور (اختياري)', 'al_gallery_box', array('service', 'project'), 'normal', 'default');
    add_meta_box('al_enquiry_box', 'بيانات الاستفسار', 'al_enquiry_box', 'al_enquiry', 'normal', 'high');
});

function al_field_row($label, $name, $value, $type = 'text', $dir = '') {
    echo '<p><label style="display:block;font-weight:600;margin-bottom:4px">' . esc_html($label) . '</label>';
    $d = $dir ? ' dir="' . esc_attr($dir) . '"' : '';
    if ($type === 'textarea') { echo '<textarea name="' . esc_attr($name) . '" rows="3" class="large-text"' . $d . '>' . esc_textarea($value) . '</textarea>'; }
    else { echo '<input type="text" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '" class="large-text"' . $d . '>'; }
    echo '</p>';
}

function al_service_box($post) {
    wp_nonce_field('al_save_meta', 'al_meta_nonce');
    $g = function ($k) use ($post) { return get_post_meta($post->ID, $k, true); };
    echo '<p class="description">العنوان والوصف المختصر (Excerpt) والمحتوى بالإنجليزية يُكتبون في حقول ووردبريس الأساسية، والصورة الأساسية من «الصورة البارزة». الوصف المختصر يظهر في كارت الخدمة وفي مقدمة صفحة الخدمة.</p>';
    al_field_row('العنوان بالعربية', 'al_title_ar', $g('al_title_ar'), 'text', 'rtl');
    al_field_row('الوصف المختصر بالعربية (يظهر في الكارت وفي مقدمة الصفحة)', 'al_excerpt_ar', $g('al_excerpt_ar'), 'textarea', 'rtl');
    al_field_row('نظرة عامة (الوصف التفصيلي) بالعربية', 'al_desc_ar', $g('al_desc_ar'), 'textarea', 'rtl');
    al_field_row('خطوات العمل بالإنجليزية (خطوة في كل سطر)', 'al_steps', $g('al_steps'), 'textarea');
    al_field_row('خطوات العمل بالعربية (خطوة في كل سطر)', 'al_steps_ar', $g('al_steps_ar'), 'textarea', 'rtl');
    echo '<p><label><input type="checkbox" name="al_hide_home" value="1" ' . checked($g('al_hide_home'), '1', false) . '> إخفاء هذه الخدمة من الصفحة الرئيسية</label></p>';
    echo '<p class="description">الترتيب: استخدم حقل «الترتيب» (Order) في مربع «خصائص الصفحة» — الرقم الأصغر يظهر أولاً.</p>';
}

function al_project_box($post) {
    wp_nonce_field('al_save_meta', 'al_meta_nonce');
    $g = function ($k) use ($post) { return get_post_meta($post->ID, $k, true); };
    echo '<p class="description">العنوان والوصف المختصر بالإنجليزية في الحقول الأساسية، والتصنيف من «تصنيفات المشاريع».</p>';
    al_field_row('العنوان بالعربية', 'al_title_ar', $g('al_title_ar'), 'text', 'rtl');
    al_field_row('الوصف المختصر بالعربية', 'al_excerpt_ar', $g('al_excerpt_ar'), 'textarea', 'rtl');
    al_field_row('الموقع بالإنجليزية (Location)', 'al_location', $g('al_location'));
    al_field_row('الموقع بالعربية', 'al_location_ar', $g('al_location_ar'), 'text', 'rtl');
}

function al_gallery_box($post) {
    $ids = get_post_meta($post->ID, 'al_gallery', true);
    echo '<input type="hidden" id="al_gallery" name="al_gallery" value="' . esc_attr($ids) . '">';
    echo '<div id="al_gallery_preview" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">';
    foreach (array_filter(array_map('intval', explode(',', (string) $ids))) as $id) {
        echo '<img src="' . esc_url(wp_get_attachment_image_url($id, 'thumbnail')) . '" style="width:80px;height:80px;object-fit:cover;border-radius:6px">';
    }
    echo '</div><button type="button" class="button" id="al_gallery_btn">اختيار / تعديل الصور</button> <button type="button" class="button" id="al_gallery_clear">مسح</button>';
    echo '<p class="description">إن تركته فارغاً ستظهر الصور الافتراضية للتصميم. اختر عدة صور دفعة واحدة وسيتم عرضها بالترتيب.</p>';
    ?>
    <script>
    jQuery(function($){
        var frame;
        $('#al_gallery_btn').on('click',function(e){e.preventDefault();
            if(!frame){frame=wp.media({title:'اختر صور المعرض',multiple:'add',library:{type:'image'}});
                frame.on('select',function(){var ids=[],h='';frame.state().get('selection').each(function(a){ids.push(a.id);var u=(a.attributes.sizes&&a.attributes.sizes.thumbnail)?a.attributes.sizes.thumbnail.url:a.attributes.url;h+='<img src="'+u+'" style="width:80px;height:80px;object-fit:cover;border-radius:6px">';});
                $('#al_gallery').val(ids.join(','));$('#al_gallery_preview').html(h);});}
            frame.open();});
        $('#al_gallery_clear').on('click',function(){$('#al_gallery').val('');$('#al_gallery_preview').empty();});
    });
    </script>
    <?php
}

function al_enquiry_box($post) {
    $fields = array('name' => 'الاسم', 'company' => 'الشركة', 'email' => 'البريد', 'phone' => 'الجوال', 'service' => 'الخدمة', 'city' => 'المدينة', 'message' => 'التفاصيل', 'lang' => 'لغة الموقع', 'mail_status' => 'حالة إرسال الإيميل');
    echo '<table class="widefat striped"><tbody>';
    foreach ($fields as $k => $label) {
        echo '<tr><th style="width:160px">' . esc_html($label) . '</th><td>' . nl2br(esc_html(get_post_meta($post->ID, 'al_f_' . $k, true))) . '</td></tr>';
    }
    echo '</tbody></table>';
}

add_action('save_post', function ($post_id) {
    if (!isset($_POST['al_meta_nonce']) || !wp_verify_nonce($_POST['al_meta_nonce'], 'al_save_meta')) { return; }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
    if (!current_user_can('edit_post', $post_id)) { return; }
    $text = array('al_title_ar', 'al_location', 'al_location_ar');
    $area = array('al_excerpt_ar', 'al_desc_ar', 'al_steps', 'al_steps_ar');
    foreach ($text as $k) { if (isset($_POST[$k])) { update_post_meta($post_id, $k, sanitize_text_field(wp_unslash($_POST[$k]))); } }
    foreach ($area as $k) { if (isset($_POST[$k])) { update_post_meta($post_id, $k, sanitize_textarea_field(wp_unslash($_POST[$k]))); } }
    if (get_post_type($post_id) === 'service') {
        update_post_meta($post_id, 'al_hide_home', isset($_POST['al_hide_home']) ? '1' : '');
    }
    if (isset($_POST['al_gallery'])) {
        $ids = implode(',', array_filter(array_map('intval', explode(',', wp_unslash($_POST['al_gallery'])))));
        update_post_meta($post_id, 'al_gallery', $ids);
    }
});

/* --------------------------------------------------------- admin columns */
add_filter('manage_service_posts_columns', function ($c) { $c['al_order'] = 'الترتيب'; $c['al_img'] = 'الصورة'; return $c; });
add_filter('manage_project_posts_columns', function ($c) { $c['al_order'] = 'الترتيب'; $c['al_img'] = 'الصورة'; return $c; });
add_action('manage_service_posts_custom_column', 'al_admin_col', 10, 2);
add_action('manage_project_posts_custom_column', 'al_admin_col', 10, 2);
function al_admin_col($col, $id) {
    if ($col === 'al_order') { echo (int) get_post_field('menu_order', $id); }
    if ($col === 'al_img') { echo '<img src="' . esc_url(al_post_image_url($id, 'thumbnail')) . '" style="width:60px;height:40px;object-fit:cover;border-radius:4px">'; }
}
add_filter('manage_al_enquiry_posts_columns', function () {
    return array('cb' => '<input type="checkbox">', 'title' => 'الاسم', 'al_phone' => 'الجوال', 'al_email' => 'البريد', 'al_service' => 'الخدمة', 'al_mail' => 'الإيميل', 'date' => 'التاريخ');
});
add_action('manage_al_enquiry_posts_custom_column', function ($col, $id) {
    $map = array('al_phone' => 'phone', 'al_email' => 'email', 'al_service' => 'service', 'al_mail' => 'mail_status');
    if (isset($map[$col])) { echo esc_html(get_post_meta($id, 'al_f_' . $map[$col], true)); }
}, 10, 2);

/* media uploader for post screens */
add_action('admin_enqueue_scripts', function ($hook) {
    if (in_array($hook, array('post.php', 'post-new.php'), true)) { wp_enqueue_media(); }
});
