<?php
/**
 * Contact / enquiry form: validation, storage (dashboard), e-mail delivery, optional built-in SMTP.
 */
if (!defined('ABSPATH')) { exit; }

add_action('admin_post_nopriv_alenaya_contact', 'al_handle_contact');
add_action('admin_post_alenaya_contact', 'al_handle_contact');

function al_form_respond($ok, $msg, $redirect) {
    $is_ajax = (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') || !empty($_POST['al_ajax']);
    if ($is_ajax) {
        wp_send_json(array('ok' => $ok, 'message' => $msg), $ok ? 200 : 400);
    }
    $url = $redirect ? $redirect : home_url('/');
    $url = add_query_arg('al_sent', $ok ? '1' : '0', $url) . '#contact-form';
    wp_safe_redirect($url);
    exit;
}

function al_handle_contact() {
    $redirect = isset($_POST['al_redirect']) ? esc_url_raw(wp_unslash($_POST['al_redirect'])) : '';
    $lang = (isset($_POST['al_lang']) && $_POST['al_lang'] === 'en') ? 'en' : 'ar';
    $ok_msg = $lang === 'ar' ? al_t('contact.contact-section.' . 'status_ok', 'ar') : '';
    $ok_msg = al_form_success_text($lang);
    $err = al_t('single.form.error', $lang);

    if (!isset($_POST['al_nonce']) || !wp_verify_nonce($_POST['al_nonce'], 'alenaya_contact')) {
        al_form_respond(false, $err, $redirect);
    }
    if (!empty($_POST['al_website'])) { // honeypot
        al_form_respond(true, $ok_msg, $redirect);
    }
    // basic rate limit: 1 submission / 20 sec / IP
    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'x';
    $tk = 'al_rl_' . md5($ip);
    if (get_transient($tk)) { al_form_respond(false, $err, $redirect); }

    $f = array();
    foreach (array('name', 'company', 'email', 'phone', 'service', 'city') as $k) {
        $f[$k] = isset($_POST[$k]) ? sanitize_text_field(wp_unslash($_POST[$k])) : '';
    }
    $f['message'] = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
    if ($f['name'] === '' || !is_email($f['email']) || $f['phone'] === '' || $f['service'] === '' || $f['message'] === '') {
        al_form_respond(false, $err, $redirect);
    }
    set_transient($tk, 1, 20);

    $post_id = wp_insert_post(array('post_type' => 'al_enquiry', 'post_status' => 'publish', 'post_title' => $f['name'] . ' — ' . $f['service']));
    if ($post_id && !is_wp_error($post_id)) {
        foreach ($f as $k => $v) { update_post_meta($post_id, 'al_f_' . $k, $v); }
        update_post_meta($post_id, 'al_f_lang', $lang);
    }

    $to = al_opt('form_to');
    if (!is_email($to)) { $to = get_option('admin_email'); }
    $subject = '[AL-ENAYA] طلب / استفسار جديد: ' . $f['service'] . ' — ' . $f['name'];
    $body = "تم استلام استفسار جديد من موقع العناية\n\n"
        . 'الاسم: ' . $f['name'] . "\n" . 'الشركة: ' . $f['company'] . "\n" . 'البريد: ' . $f['email'] . "\n" . 'الجوال: ' . $f['phone'] . "\n"
        . 'الخدمة: ' . $f['service'] . "\n" . 'المدينة: ' . $f['city'] . "\n" . "التفاصيل:\n" . $f['message'] . "\n\n---\nلغة الموقع: " . $lang . "\nIP: " . $ip . "\n";
    $headers = array('Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $f['name'] . ' <' . $f['email'] . '>');
    $cc = al_opt('form_cc');
    if ($cc) { foreach (array_filter(array_map('trim', explode(',', $cc))) as $c) { if (is_email($c)) { $headers[] = 'Cc: ' . $c; } } }

    $GLOBALS['al_mail_error'] = '';
    $sent = wp_mail($to, $subject, $body, $headers);
    if ($post_id) { update_post_meta($post_id, 'al_f_mail_status', $sent ? 'تم الإرسال إلى ' . $to : 'فشل الإرسال: ' . $GLOBALS['al_mail_error']); }

    // We always show success when the enquiry was stored in the dashboard (nothing is lost).
    al_form_respond(true, $ok_msg, $redirect);
}

function al_form_success_text($lang) {
    return $lang === 'ar'
        ? 'شكراً لك. تم إرسال استفسارك بنجاح وسيتواصل معك فريقنا قريباً.'
        : 'Thank you. Your enquiry has been sent successfully and our team will contact you shortly.';
}

add_action('wp_mail_failed', function ($err) {
    if ($err instanceof WP_Error) { $GLOBALS['al_mail_error'] = $err->get_error_message(); }
});

/* ---------------- sender name/email */
add_filter('wp_mail_from_name', function ($n) { $v = al_opt('form_from_name'); return $v ? $v : $n; });
add_filter('wp_mail_from', function ($e) { $v = al_opt('form_from_email'); return is_email($v) ? $v : $e; });

/* ---------------- optional built-in SMTP (use it OR a plugin such as WP Mail SMTP) */
add_action('phpmailer_init', function ($m) {
    if (al_opt('smtp_enable') !== '1' || !al_opt('smtp_host')) { return; }
    $m->isSMTP();
    $m->Host = al_opt('smtp_host');
    $m->Port = (int) al_opt('smtp_port');
    $sec = al_opt('smtp_secure');
    $m->SMTPSecure = in_array($sec, array('ssl', 'tls'), true) ? $sec : '';
    $m->SMTPAutoTLS = $sec === 'tls';
    if (al_opt('smtp_user') !== '') {
        $m->SMTPAuth = true;
        $m->Username = al_opt('smtp_user');
        $m->Password = al_opt('smtp_pass');
    }
    $from = al_opt('form_from_email');
    if (!is_email($from)) { $from = al_opt('smtp_user'); }
    if (is_email($from)) { $m->From = $from; $m->Sender = $from; }
});
