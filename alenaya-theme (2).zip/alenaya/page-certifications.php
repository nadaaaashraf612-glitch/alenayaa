<?php
/**
 * Template Name: Al-Enaya Certifications
 * Generated from the original Al-Enaya static design.
 */
al_set_header_variant('internal');
get_header();
?>
<main>
<section class="hero" style="--hero-img:url(<?php echo esc_url(al_img('certifications.hero.bg')); ?>);"><div class="shell hero-content"><p class="eyebrow"><?php al_e('certifications.hero.1'); ?></p><h1><span><?php al_e('certifications.hero.2'); ?></span><span><?php al_e('certifications.hero.3'); ?></span></h1></div><div class="hero-line"></div></section>
<section class="certifications"><div class="shell"><div class="cert-panel"><div class="cert-head"><div><p class="eyebrow"><?php al_e('certifications.certifications.1'); ?></p><h2><?php al_e('certifications.certifications.2'); ?></h2></div></div><div class="cert-grid">
<article class="cert-card"><span class="cert-icon"><svg viewbox="0 0 24 24"><path d="m12 3 7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6Z"></path><path d="m9 12 2 2 4-4"></path></svg></span><div><span class="cert-code"><?php al_e('certifications.certifications.3'); ?></span><h3><?php al_e('certifications.certifications.4'); ?></h3></div><button class="cert-download" disabled=""><?php al_e('certifications.certifications.5'); ?> <svg viewbox="0 0 24 24"><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 21h14"></path></svg></button></article>
<article class="cert-card"><span class="cert-icon"><svg viewbox="0 0 24 24"><path d="M19 4C10 4 5 8 5 15c4 1 8 0 10-3"></path><path d="M5 20c1-6 5-10 12-13"></path></svg></span><div><span class="cert-code"><?php al_e('certifications.certifications.6'); ?></span><h3><?php al_e('certifications.certifications.7'); ?></h3></div><button class="cert-download" disabled=""><?php al_e('certifications.certifications.8'); ?> <svg viewbox="0 0 24 24"><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 21h14"></path></svg></button></article>
<article class="cert-card"><span class="cert-icon"><svg viewbox="0 0 24 24"><path d="M8 11V8a4 4 0 0 1 8 0v3"></path><rect height="10" rx="2" width="14" x="5" y="11"></rect></svg></span><div><span class="cert-code"><?php al_e('certifications.certifications.9'); ?></span><h3><?php al_e('certifications.certifications.10'); ?></h3></div><button class="cert-download" disabled=""><?php al_e('certifications.certifications.11'); ?> <svg viewbox="0 0 24 24"><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 21h14"></path></svg></button></article>
<article class="cert-card"><span class="cert-icon"><svg viewbox="0 0 24 24"><path d="M12 3 3 20h18Z"></path><path d="M12 9v5M12 17v.01"></path></svg></span><div><span class="cert-code"><?php al_e('certifications.certifications.12'); ?></span><h3><?php al_e('certifications.certifications.13'); ?></h3></div><button class="cert-download" disabled=""><?php al_e('certifications.certifications.14'); ?> <svg viewbox="0 0 24 24"><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 21h14"></path></svg></button></article>
<article class="cert-card"><span class="cert-icon"><svg viewbox="0 0 24 24"><path d="M4 21V7l8-4 8 4v14M8 10h2M14 10h2M8 14h2M14 14h2M9 21v-3h6v3"></path></svg></span><div><span class="cert-code"><?php al_e('certifications.certifications.15'); ?></span><h3><?php al_e('certifications.certifications.16'); ?></h3></div><button class="cert-download" disabled=""><?php al_e('certifications.certifications.17'); ?> <svg viewbox="0 0 24 24"><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 21h14"></path></svg></button></article>
</div></div></div></section>
</main>
<?php get_footer(); ?>
