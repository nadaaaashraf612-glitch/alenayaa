<?php
if (!defined('ABSPATH')) { exit; }
al_set_header_variant('internal');
get_header();
?>
<main class="legal-main">
<section class="legal-hero"><div class="shell legal-hero-inner"><h1><?php echo esc_html(wp_strip_all_tags(get_the_title() ? get_the_title() : get_bloginfo('name'))); ?></h1></div></section>
<div class="shell al-results">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <article class="al-result"><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><div><?php the_content(); ?></div></article>
<?php endwhile; endif; ?>
</div></main>
<?php get_footer(); ?>
