<?php
if (!defined('ABSPATH')) { exit; }
al_set_header_variant('home');
$term = get_queried_object();
$title = al_term_field($term, 'page_title');
$title_html = str_replace('&amp;', '<span>&amp;</span>', esc_html($title));
$posts = get_posts(array('post_type' => 'project', 'posts_per_page' => -1, 'orderby' => 'menu_order title', 'order' => 'ASC', 'tax_query' => array(array('taxonomy' => 'project_category', 'field' => 'term_id', 'terms' => $term->term_id))));
get_header();
?>
<main>
<section class="hero"><div class="shell hero-content"><a class="back" href="<?php echo esc_url(al_url('projects')); ?>">← <?php al_e('single.cat.back'); ?></a>
<h1><?php echo $title_html; ?></h1><p><?php echo esc_html(al_term_field($term, 'page_desc')); ?></p></div><div class="hero-line"></div></section>
<section class="projects"><div class="shell"><div class="projects-head"><div><p class="eyebrow"><?php al_e('single.cat.eyebrow'); ?></p><h2><?php al_e('single.cat.title'); ?></h2></div><span class="count"><?php echo esc_html(al_count_label(count($posts))); ?></span></div>
<div class="project-list">
<?php foreach ($posts as $i => $p) : ?>
<a class="project-card" href="<?php echo esc_url(get_permalink($p)); ?>"><span class="number"><?php echo str_pad($i + 1, 2, '0', STR_PAD_LEFT); ?></span><h3><?php echo esc_html(al_post_field($p->ID, 'title')); ?></h3><p><?php echo esc_html(al_post_field($p->ID, 'excerpt')); ?></p><span class="location"><svg viewBox="0 0 24 24"><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></svg><?php echo esc_html(al_post_field($p->ID, 'location')); ?></span></a>
<?php endforeach; ?>
</div></div></section>
</main>
<?php get_footer(); ?>
