<?php
if (!defined('ABSPATH')) { exit; }
$al_v = al_header_variant();
$al_cur = '';
if (is_front_page()) { $al_cur = 'home'; }
elseif (is_page('about')) { $al_cur = 'about'; }
elseif (is_page('services') || is_singular('service') || is_tax('service_category')) { $al_cur = 'services'; }
elseif (is_page('projects') || is_singular('project') || is_tax('project_category')) { $al_cur = 'projects'; }
elseif (is_page('clients')) { $al_cur = 'clients'; }
elseif (is_page('contact')) { $al_cur = 'contact'; }
$al_nav = array('home' => 'global.nav.home', 'about' => 'global.nav.about', 'services' => 'global.nav.services', 'projects' => 'global.nav.projects', 'clients' => 'global.nav.clients');
$al_search = al_search_index_items();
$al_cur_lang = al_lang();
$al_search_svg = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4 4"/></svg>';
?><!doctype html>
<html lang="<?php echo esc_attr(al_lang_attr()); ?>" dir="<?php echo al_is_rtl() ? 'rtl' : 'ltr'; ?>">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#0155B6">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header" data-od-id="site-header">
<nav class="nav shell<?php echo $al_v === 'internal' ? ' internal-nav' : ''; ?>" aria-label="Primary navigation">
    <a class="brand brand-en" href="<?php echo esc_url(home_url('/')); ?>" aria-label="AL-ENAYA — Home"><?php if ($al_v === 'internal') : ?><span class="brand-icon brand-logo-image brand-logo-icon"></span><span class="brand-word brand-wordmark">AL-ENAYA</span><?php else : ?><span class="brand-logo-image brand-logo-icon" role="img" aria-label="AL-ENAYA icon"></span><span class="brand-wordmark">AL-ENAYA</span><?php endif; ?></a>
    <a class="brand brand-ar" href="<?php echo esc_url(home_url('/')); ?>" aria-label="العناية — الرئيسية"><span class="brand-logo-image brand-logo-full" role="img" aria-label="شعار العناية"></span></a>
    <div class="nav-links" id="al-nav-links">
        <?php foreach ($al_nav as $k => $key) : ?>
            <a<?php echo $al_cur === $k ? ' class="active"' : ''; ?> href="<?php echo esc_url(al_url($k)); ?>"><?php al_e($key); ?></a>
        <?php endforeach; ?>
    </div>
    <div class="nav-actions">
        <div class="language-switch" aria-label="Language and search">
            <?php if (al_opt('show_lang_switch') === '1') : ?>
                <button class="<?php echo $al_cur_lang === 'en' ? 'language-current' : ''; ?>" type="button" data-lang="en" aria-label="English language"<?php echo $al_cur_lang === 'en' ? ' aria-current="true"' : ''; ?>>EN</button>
                <span class="nav-separator" aria-hidden="true">/</span>
                <button class="<?php echo $al_cur_lang === 'ar' ? 'language-current' : ''; ?>" type="button" data-lang="ar" aria-label="Arabic language"<?php echo $al_cur_lang === 'ar' ? ' aria-current="true"' : ''; ?>>AR</button>
                <span class="nav-separator" aria-hidden="true">/</span>
            <?php endif; ?>
            <button class="nav-search-toggle" type="button" aria-label="Search" aria-expanded="false" aria-controls="nav-service-search"><?php echo $al_search_svg; ?></button>
        </div>
        <a class="<?php echo $al_v === 'internal' ? 'nav-contact' . ($al_cur === 'contact' ? ' active' : '') : 'btn btn-primary'; ?>" href="<?php echo esc_url(al_url('contact')); ?>"><?php al_e('global.nav.contact'); ?></a>
        <button class="menu-btn" type="button" aria-label="Menu" aria-expanded="false" aria-controls="al-nav-links"><svg viewBox="0 0 24 24" width="22" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M5 8h14M5 16h14"/></svg></button>
    </div>
    <div class="nav-search-panel" id="nav-service-search" hidden>
        <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>" class="al-search-form">
            <label class="nav-search-field"><?php echo $al_search_svg; ?><input type="search" name="s" placeholder="<?php al_a('global.search.placeholder'); ?>" autocomplete="off" aria-label="<?php al_a('global.search.placeholder'); ?>"></label>
            <button class="screen-reader-text" type="submit"><?php al_e('global.search.all'); ?></button>
        </form>
        <div class="nav-search-results">
            <?php foreach ($al_search as $it) : ?>
                <a class="nav-search-result" href="<?php echo esc_url($it['url']); ?>" data-search="<?php echo esc_attr($it['hay']); ?>" data-search-service="<?php echo esc_attr($it['hay']); ?>"><?php echo esc_html($it['title']); ?> <span><?php al_e('global.search.view'); ?></span></a>
            <?php endforeach; ?>
        </div>
        <p class="nav-search-empty"><?php al_e('global.search.empty'); ?></p>
    </div>
</nav>
</header>
